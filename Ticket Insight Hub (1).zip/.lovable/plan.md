## Problema

No card **Dados do ticket** (tela de resultado) e no formulário de análise, alguns campos vazam a largura da coluna:

- **Categoria / Criado em / Prazo final**: os valores longos (ex.: "Desenvolvimento", datas completas) ficam colados na borda direita e cortam quando a coluna é estreita.
- **Descrição e Logs**: o texto/`<pre>` estoura horizontalmente porque o container `Field` não impõe `min-w-0` e o `<pre>` só tem `overflow-auto` vertical.

Causa raiz: em `TicketDataCard.tsx` o `Field` usa `flex` sem `min-w-0` no wrapper externo, e o `<pre>` dos logs não tem `whitespace-pre-wrap`/`overflow-x-auto`. No formulário, os inputs `datetime-local` e o combobox de categoria não têm largura mínima controlada, gerando overflow em telas médias.

## Mudanças

### 1. `src/components/ticket/TicketDataCard.tsx`
- Adicionar `min-w-0` ao container raiz do `Field` (o `flex items-start gap-3`) para permitir shrink real do conteúdo.
- Trocar o `<pre>` dos Logs por container com `overflow-x-auto` + `whitespace-pre` (mantém formatação mas rola horizontalmente sem vazar).
- Garantir `break-words` + `overflow-wrap-anywhere` na Descrição.
- Nos campos curtos (Categoria, Criado em, Prazo final): envolver o valor em `truncate` quando cabível, mas manter `break-words` para strings longas.

### 2. `src/components/ticket/TicketForm.tsx`
- No grid `sm:grid-cols-2`, adicionar `min-w-0` em cada `Field` para os inputs `datetime-local` e o combobox não estourarem.
- Garantir `w-full` no `Input datetime-local` (alguns browsers dão largura intrínseca).

### 3. `src/routes/resultado.$id.tsx` (verificar)
- Confirmar que a coluna que contém o `TicketDataCard` usa `min-w-0` dentro do grid para não empurrar layout.

Nenhuma mudança de lógica ou de dados — apenas classes Tailwind de layout/overflow.
