// Contratos EXATOS da API FastAPI (fonte: /openapi.json + resposta real)

export interface TicketRequest {
  id: number;
  descricao: string;
  status: string;
  categoria: string;
  prioridade: string;
  logs: string;
  criado_em: string; // ISO datetime
  prazo_final: string; // ISO datetime
}

export interface ArtigoUtilizado {
  id: string;
  categoria: string;
  texto: string;
}

export interface TicketSemelhante {
  id: string;
  categoria: string;
  texto: string;
}

export interface DiagnosticoResponse {
  causa_provavel: string;
  criticidade: string;
  confianca: number;
  acoes_recomendadas: string[];
  necessita_escalonamento: boolean;
  rascunho_resposta: string;
  artigos_utilizados: ArtigoUtilizado[];
  tickets_semelhantes: TicketSemelhante[];
}

export interface ApiError {
  status: number;
  message: string;
  detail?: Array<{
    loc: (string | number)[];
    msg: string;
    type: string;
  }>;
}

export interface AnaliseHistoricoItem {
  request: TicketRequest;
  response: DiagnosticoResponse;
  analisadoEm: string;
  duracaoMs?: number;
  templateIdUsed?: string;
  articlesReferenced?: string[];
}

// ---------- Knowledge Base (local) ----------
export interface KbCategory {
  id: string;
  name: string;
  color: string; // hex/oklch or preset key
  icon: string; // lucide icon name
  createdAt: string;
  updatedAt: string;
}

export interface KbArticle {
  id: string;
  categoryId: string;
  title: string;
  body: string; // markdown
  tags: string[];
  updatedAt: string;
}

// ---------- Prompt Templates (local) ----------
export type PromptScope = "diagnostico" | "resposta" | "triagem";

export interface PromptTemplate {
  id: string;
  name: string;
  scope: PromptScope;
  body: string;
  version: number;
  active: boolean;
  updatedAt: string;
  history?: Array<{ version: number; body: string; updatedAt: string }>;
}
