import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sparkles } from "lucide-react";
import { useHistoricoStore } from "@/hooks/useHistoricoStore";
import { TicketDataCard } from "@/components/ticket/TicketDataCard";
import { DiagnosticoCard } from "@/components/ticket/DiagnosticoCard";
import { ArtigosList } from "@/components/ticket/ArtigosList";
import { TicketsSemelhantesList } from "@/components/ticket/TicketsSemelhantesList";
import { useAnalisarTicket } from "@/hooks/useAnalisarTicket";
import { LoadingAnalise } from "@/components/ticket/LoadingAnalise";
import { AnalysisReplay } from "@/components/ticket/AnalysisReplay";
import { CopilotDrawer } from "@/components/ticket/CopilotDrawer";
import { formatDateTime } from "@/utils/format";
import { useHydrated } from "@/hooks/useHydrated";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/resultado/$id")({
  head: () => ({
    meta: [
      { title: "Resultado da análise — Copiloto IA" },
      {
        name: "description",
        content: "Diagnóstico completo gerado pela IA para o ticket selecionado.",
      },
    ],
  }),
  component: ResultadoPage,
});

function ResultadoPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const item = useHistoricoStore((s) => s.obter(Number(id)));
  const mutation = useAnalisarTicket();
  const hydrated = useHydrated();
  const [replayDone, setReplayDone] = useState(false);
  useEffect(() => setReplayDone(false), [id]);

  if (!hydrated) {
    return <AppLayout title="Resultado da análise" breadcrumb={`Ticket #${id}`}>{null}</AppLayout>;
  }

  if (!item) {
    return (
      <AppLayout title="Resultado da análise" breadcrumb={`Ticket #${id}`}>
        <div className="mx-auto max-w-2xl">
          <Card>
            <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
              <div className="text-sm font-medium">Análise não encontrada</div>
              <p className="max-w-md text-sm text-muted-foreground">
                O ticket #{id} não está no histórico desta sessão. Envie o ticket
                novamente para o Copiloto IA analisar.
              </p>
              <Button asChild size="sm">
                <Link to="/analise">
                  <Sparkles className="mr-1.5 h-4 w-4" />
                  Nova análise
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title={`Ticket #${item.request.id}`}
      breadcrumb={`Analisado em ${formatDateTime(item.analisadoEm)}`}
      actions={
        <div className="flex gap-2">
          <CopilotDrawer categoria={item.request.categoria} descricao={item.request.descricao} />
          <Button
            size="sm"
            variant="ghost"
            onClick={() => navigate({ to: "/tickets" })}
          >
            <ArrowLeft className="mr-1.5 h-4 w-4" />
            Voltar
          </Button>
          <Button
            size="sm"
            variant="outline"
            disabled={mutation.isPending}
            onClick={() =>
              mutation.mutate(item.request, {
                onSuccess: () =>
                  navigate({
                    to: "/resultado/$id",
                    params: { id: String(item.request.id) },
                  }),
              })
            }
          >
            <Sparkles className="mr-1.5 h-4 w-4" />
            Reanalisar
          </Button>
        </div>
      }
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <AnalysisReplay running={!replayDone} onFinish={() => setReplayDone(true)} />
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="min-w-0"><TicketDataCard ticket={item.request} /></div>
          <div className="min-w-0">
            {mutation.isPending ? <LoadingAnalise /> : <DiagnosticoCard diag={item.response} />}
          </div>
        </div>


        <div className="grid gap-6 lg:grid-cols-2">
          <ArtigosList artigos={item.response.artigos_utilizados} />
          <TicketsSemelhantesList tickets={item.response.tickets_semelhantes} />
        </div>
      </div>
    </AppLayout>
  );
}
