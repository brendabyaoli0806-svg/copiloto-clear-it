import { createFileRoute, Link } from "@tanstack/react-router";
import { HeroManifesto } from "@/components/landing/HeroManifesto";
import { PillarsGrid } from "@/components/landing/PillarsGrid";
import { SquadSection } from "@/components/landing/SquadSection";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Copiloto IA da Clear IT — L1 com experiência de L3" },
      {
        name: "description",
        content:
          "O Copiloto de Suporte L1 da Clear IT transforma conhecimento tribal em diagnóstico, ações e rascunho de resposta em até 10 segundos.",
      },
      { property: "og:title", content: "Copiloto IA da Clear IT" },
      {
        property: "og:description",
        content:
          "Dar ao L1 a experiência de um L3, no exato segundo da crise. Feito pela Squad Tech Tigers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <div className="dark aurora-bg min-h-screen bg-background text-foreground">
    <nav className="w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-6 py-4 flex justify-between items-center sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Tech Tigers
            </span>
          </div>
          <a 
            href="https://drive.google.com/file/d/1koSW9AtihTswrBxcyn64rMVWM3iqcWla/view?usp=drivesdk" 
            target="_blank" 
            rel="noreferrer"
          >
            <Button size="sm" className="bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-sm">
              Manual do Sistema
            </Button>
          </a>
        </nav>
      <HeroManifesto />
      <PillarsGrid />
      <SquadSection />

      <section className="border-t border-border/60 bg-card/20 backdrop-blur">
        <div className="mx-auto flex max-w-4xl flex-col items-center gap-4 px-6 py-16 text-center">
          <h3 className="font-display text-2xl font-bold md:text-3xl">
            Pronto para acelerar o próximo ticket?
          </h3>
          <p className="max-w-xl text-sm text-muted-foreground">
            Abra o Copiloto e veja diagnóstico, ações e rascunho de resposta serem
            gerados em tempo real.
          </p>
          <Button
            asChild
            size="lg"
            className="mt-3 bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-[0_0_40px_-8px_oklch(0.78_0.18_210_/_0.6)]"
          >
            <Link to="/painel">
              <Zap className="mr-2 h-4 w-4" />
              Entrar no Copiloto
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
