import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { useState } from "react";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  FilePlus2,
  Save,
  Trash2,
  Tag,
  BookOpen,
} from "lucide-react";
import { useKnowledgeStore } from "@/hooks/useKnowledgeStore";
import { useHydrated } from "@/hooks/useHydrated";
import { formatRelative } from "@/utils/format";
import ReactMarkdown from "react-markdown";

const searchSchema = z.object({
  article: z.string().optional(),
});

export const Route = createFileRoute("/conhecimento/$categoryId")({
  validateSearch: (s) => searchSchema.parse(s),
  head: ({ params }) => ({
    meta: [
      { title: `KB · ${params.categoryId} — Copiloto IA` },
      { name: "description", content: "Artigos da base de conhecimento." },
    ],
  }),
  component: CategoryPage,
});

function CategoryPage() {
  const { categoryId } = Route.useParams();
  const { article: activeSearch } = Route.useSearch();
  const navigate = useNavigate();
  const hydrated = useHydrated();

  const categories = useKnowledgeStore((s) => s.categories);
  const articles = useKnowledgeStore((s) => s.articles);
  const createArticle = useKnowledgeStore((s) => s.createArticle);
  const updateArticle = useKnowledgeStore((s) => s.updateArticle);
  const deleteArticle = useKnowledgeStore((s) => s.deleteArticle);

  const category = categories.find((c) => c.id === categoryId);
  const list = articles.filter((a) => a.categoryId === categoryId);
  const [selectedId, setSelectedId] = useState<string | null>(
    activeSearch ?? list[0]?.id ?? null,
  );
  const selected = list.find((a) => a.id === selectedId) ?? list[0];

  if (!hydrated) return <AppLayout title="Base de conhecimento">{null}</AppLayout>;

  if (!category) {
    return (
      <AppLayout title="Categoria não encontrada" breadcrumb="KB">
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Esta categoria não existe.{" "}
            <Link to="/conhecimento" className="text-primary underline">
              Voltar
            </Link>
          </CardContent>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title={category.name}
      breadcrumb="KB · Categoria"
      actions={
        <div className="flex gap-2">
          <Button asChild size="sm" variant="ghost">
            <Link to="/conhecimento">
              <ArrowLeft className="mr-1.5 h-4 w-4" />
              Voltar
            </Link>
          </Button>
          <Button
            size="sm"
            onClick={() => {
              const art = createArticle(categoryId, { title: "Novo artigo" });
              setSelectedId(art.id);
              navigate({
                to: "/conhecimento/$categoryId",
                params: { categoryId },
                search: { article: art.id },
              });
            }}
          >
            <FilePlus2 className="mr-1.5 h-4 w-4" />
            Novo artigo
          </Button>
        </div>
      }
    >
      <div className="mx-auto grid max-w-7xl gap-4 lg:grid-cols-[280px_1fr]">
        <Card className="h-fit border-border/60 bg-card/60 backdrop-blur">
          <CardContent className="p-2">
            {list.length === 0 ? (
              <p className="p-4 text-center text-xs text-muted-foreground">
                Nenhum artigo ainda.
              </p>
            ) : (
              <ul className="flex flex-col">
                {list.map((a) => (
                  <li key={a.id}>
                    <button
                      onClick={() => {
                        setSelectedId(a.id);
                        navigate({
                          to: "/conhecimento/$categoryId",
                          params: { categoryId },
                          search: { article: a.id },
                        });
                      }}
                      className={[
                        "flex w-full flex-col gap-0.5 rounded-md px-3 py-2 text-left transition",
                        selected?.id === a.id
                          ? "bg-primary/10 text-foreground"
                          : "hover:bg-muted/60",
                      ].join(" ")}
                    >
                      <span className="truncate text-sm font-medium">{a.title}</span>
                      <span className="text-[10px] text-muted-foreground">
                        {formatRelative(a.updatedAt)}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        {selected ? (
          <ArticleEditor
            key={selected.id}
            article={selected}
            onSave={(data) => updateArticle(selected.id, data)}
            onDelete={() => {
              if (confirm(`Excluir "${selected.title}"?`)) {
                deleteArticle(selected.id);
                setSelectedId(null);
              }
            }}
          />
        ) : (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
              <BookOpen className="h-6 w-6 text-muted-foreground" />
              <div className="text-sm">Selecione ou crie um artigo</div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}

function ArticleEditor({
  article,
  onSave,
  onDelete,
}: {
  article: { id: string; title: string; body: string; tags: string[] };
  onSave: (d: { title?: string; body?: string; tags?: string[] }) => void;
  onDelete: () => void;
}) {
  const [title, setTitle] = useState(article.title);
  const [body, setBody] = useState(article.body);
  const [tagsInput, setTagsInput] = useState(article.tags.join(", "));
  const [preview, setPreview] = useState(false);

  return (
    <Card className="border-border/60 bg-card/60 backdrop-blur">
      <CardContent className="flex flex-col gap-4 p-5">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="!text-lg font-display font-semibold"
        />

        <div className="flex flex-wrap items-center gap-2">
          <Tag className="h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={tagsInput}
            onChange={(e) => setTagsInput(e.target.value)}
            placeholder="tags separadas por vírgula"
            className="h-8 max-w-sm text-xs"
          />
          {article.tags.map((t) => (
            <Badge key={t} variant="outline">
              {t}
            </Badge>
          ))}
        </div>

        <div className="flex items-center gap-2 border-b pb-2">
          <Button
            size="sm"
            variant={preview ? "ghost" : "secondary"}
            onClick={() => setPreview(false)}
          >
            Editar
          </Button>
          <Button
            size="sm"
            variant={preview ? "secondary" : "ghost"}
            onClick={() => setPreview(true)}
          >
            Preview
          </Button>
        </div>

        {preview ? (
          <article className="prose prose-invert prose-sm min-h-64 max-w-none">
            <ReactMarkdown>{body || "_Vazio_"}</ReactMarkdown>
          </article>
        ) : (
          <Textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={16}
            className="font-mono text-xs"
            placeholder="# Título&#10;&#10;Passos, procedimentos, troubleshooting..."
          />
        )}

        <div className="flex items-center justify-between pt-2">
          <Button variant="ghost" size="sm" onClick={onDelete} className="text-destructive">
            <Trash2 className="mr-1.5 h-3.5 w-3.5" />
            Excluir
          </Button>
          <Button
            size="sm"
            onClick={() =>
              onSave({
                title,
                body,
                tags: tagsInput
                  .split(",")
                  .map((t) => t.trim())
                  .filter(Boolean),
              })
            }
          >
            <Save className="mr-1.5 h-3.5 w-3.5" />
            Salvar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
