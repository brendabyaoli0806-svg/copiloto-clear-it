import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Wand2, PlusCircle, Sparkles } from "lucide-react";
import { usePromptStore } from "@/hooks/usePromptStore";
import { useHydrated } from "@/hooks/useHydrated";
import { formatRelative, truncate } from "@/utils/format";
import type { PromptScope, PromptTemplate } from "@/types/ticket";

const scopeLabel: Record<string, string> = {
  diagnostico: "Diagnóstico",
  resposta: "Resposta",
  triagem: "Triagem",
};
const scopeTone: Record<string, string> = {
  diagnostico: "from-primary/20 to-primary/5 text-primary border-primary/30",
  resposta: "from-success/20 to-success/5 text-success border-success/30",
  triagem: "from-warning/20 to-warning/5 text-warning border-warning/30",
};

export const Route = createFileRoute("/prompts/")({
  head: () => ({
    meta: [
      { title: "Templates de prompt — Copiloto IA" },
      {
        name: "description",
        content:
          "Gerencie os prompts usados pelo Copiloto IA para diagnóstico, resposta e triagem.",
      },
    ],
  }),
  component: PromptsPage,
});

function PromptsPage() {
  const hydrated = useHydrated();
  const templates = usePromptStore((s) => s.templates);
  const createTemplate = usePromptStore((s) => s.createTemplate);
  const setActive = usePromptStore((s) => s.setActive);

  return (
    <AppLayout
      title="Templates de prompt"
      breadcrumb="Inteligência · Prompts"
      actions={
        <Button size="sm" onClick={() => createTemplate()}>
          <PlusCircle className="mr-1.5 h-4 w-4" />
          Novo template
        </Button>
      }
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-primary/10 via-accent/5 to-transparent">
          <CardContent className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/20 text-primary">
                <Wand2 className="h-5 w-5" />
              </div>
              <div>
                <div className="font-display text-lg font-semibold">
                  Prompts que moldam a IA
                </div>
                <p className="text-xs text-muted-foreground">
                  Cada escopo (diagnóstico, resposta, triagem) tem um template ativo. Alterne à vontade — o versionamento é local.
                </p>
              </div>
            </div>
            <Badge variant="secondary" className="gap-1">
              <Sparkles className="h-3 w-3" />
              {templates.length} templates
            </Badge>
          </CardContent>
        </Card>

        {!hydrated ? null : (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4 md:w-auto md:inline-grid">
              <TabsTrigger value="all">Todos ({templates.length})</TabsTrigger>
              <TabsTrigger value="diagnostico">
                Diagnóstico ({templates.filter((t) => t.scope === "diagnostico").length})
              </TabsTrigger>
              <TabsTrigger value="resposta">
                Resposta ({templates.filter((t) => t.scope === "resposta").length})
              </TabsTrigger>
              <TabsTrigger value="triagem">
                Triagem ({templates.filter((t) => t.scope === "triagem").length})
              </TabsTrigger>
            </TabsList>
            {(["all", "diagnostico", "resposta", "triagem"] as const).map((tab) => {
              const list =
                tab === "all"
                  ? templates
                  : templates.filter((t) => t.scope === (tab as PromptScope));
              return (
                <TabsContent key={tab} value={tab} className="mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {list.map((t, i) => (
                      <TemplateCard
                        key={t.id}
                        t={t}
                        i={i}
                        setActive={setActive}
                      />
                    ))}
                  </div>
                </TabsContent>
              );
            })}
          </Tabs>
        )}
      </div>
    </AppLayout>
  );
}

function TemplateCard({
  t,
  i,
  setActive,
}: {
  t: PromptTemplate;
  i: number;
  setActive: (id: string) => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: i * 0.03 }}
    >
      <Card className="group relative overflow-hidden border-border/60 bg-card/60 backdrop-blur transition hover:border-primary/40">
        <div
          className={`absolute -right-4 -top-4 h-24 w-24 rounded-full bg-gradient-to-br opacity-40 blur-2xl ${scopeTone[t.scope]}`}
        />
        <CardContent className="relative flex flex-col gap-3 p-5">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="truncate font-display text-lg font-semibold">
                {t.name}
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                <Badge
                  variant="outline"
                  className={`bg-gradient-to-br ${scopeTone[t.scope]}`}
                >
                  {scopeLabel[t.scope]}
                </Badge>
                <Badge variant="secondary">v{t.version}</Badge>
                <span className="text-muted-foreground">
                  {formatRelative(t.updatedAt)}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase text-muted-foreground">
                Ativo
              </span>
              <Switch
                checked={t.active}
                onCheckedChange={() => setActive(t.id)}
              />
            </div>
          </div>
          <pre className="max-h-32 overflow-hidden rounded-lg border border-border/40 bg-background/40 p-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
            {truncate(t.body, 320)}
          </pre>
          <div className="flex justify-end">
            <Button asChild size="sm" variant="ghost">
              <Link to="/prompts/$id" params={{ id: t.id }}>
                Abrir editor →
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
