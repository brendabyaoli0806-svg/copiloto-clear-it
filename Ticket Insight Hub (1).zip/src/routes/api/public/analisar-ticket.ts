import { createFileRoute } from "@tanstack/react-router";

const UPSTREAM = "https://web-production-f77b9.up.railway.app/analisar-ticket";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Max-Age": "86400",
};

export const Route = createFileRoute("/api/public/analisar-ticket")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: corsHeaders }),
      POST: async ({ request }) => {
        const body = await request.text();
        try {
          const upstream = await fetch(UPSTREAM, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body,
          });
          const text = await upstream.text();
          return new Response(text, {
            status: upstream.status,
            headers: {
              "Content-Type":
                upstream.headers.get("content-type") ?? "application/json",
              ...corsHeaders,
            },
          });
        } catch (err) {
          return new Response(
            JSON.stringify({
              detail: err instanceof Error ? err.message : "Upstream error",
            }),
            {
              status: 502,
              headers: { "Content-Type": "application/json", ...corsHeaders },
            },
          );
        }
      },
    },
  },
});
