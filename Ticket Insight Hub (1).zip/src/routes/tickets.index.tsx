import { createFileRoute, Link } from "@tanstack/react-router";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useHistoricoStore } from "@/hooks/useHistoricoStore";
import { CriticidadeBadge } from "@/components/ticket/CriticidadeBadge";
import { formatDateTime, formatPercent, truncate } from "@/utils/format";
import { Sparkles, Trash2 } from "lucide-react";

export const Route = createFileRoute("/tickets/")({
  head: () => ({
    meta: [
      { title: "Tickets — Copiloto IA" },
      {
        name: "description",
        content: "Lista de tickets analisados pelo Copiloto IA nesta sessão.",
      },
    ],
  }),
  component: TicketsPage,
});

function TicketsPage() {
  const itens = useHistoricoStore((s) => s.itens);
  const limpar = useHistoricoStore((s) => s.limpar);

  return (
    <AppLayout
      title="Tickets analisados"
      breadcrumb="Histórico da sessão"
      actions={
        <div className="flex gap-2">
          {itens.length > 0 && (
            <Button size="sm" variant="ghost" onClick={limpar}>
              <Trash2 className="mr-1.5 h-4 w-4" />
              Limpar
            </Button>
          )}
          <Button asChild size="sm">
            <Link to="/analise">
              <Sparkles className="mr-1.5 h-4 w-4" />
              Nova análise
            </Link>
          </Button>
        </div>
      }
    >
      <div className="mx-auto max-w-7xl">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">
              {itens.length} ticket{itens.length === 1 ? "" : "s"}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {itens.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-3 py-14 text-center">
                <div className="text-sm text-muted-foreground">
                  Nenhum ticket analisado nesta sessão ainda.
                </div>
                <Button asChild size="sm">
                  <Link to="/analise">
                    <Sparkles className="mr-1.5 h-4 w-4" />
                    Analisar primeiro ticket
                  </Link>
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-20">ID</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Criticidade</TableHead>
                    <TableHead>Confiança</TableHead>
                    <TableHead>Escalonar</TableHead>
                    <TableHead>Analisado em</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {itens.map((item) => (
                    <TableRow
                      key={item.request.id}
                      className="cursor-pointer"
                      onClick={() => {
                        // navegação via <Link> abaixo é o alvo real; fallback:
                      }}
                    >
                      <TableCell>
                        <Link
                          to="/resultado/$id"
                          params={{ id: String(item.request.id) }}
                          className="font-mono text-xs text-primary hover:underline"
                        >
                          #{item.request.id}
                        </Link>
                      </TableCell>
                      <TableCell className="max-w-md">
                        <Link
                          to="/resultado/$id"
                          params={{ id: String(item.request.id) }}
                          className="hover:underline"
                        >
                          {truncate(item.request.descricao, 90)}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{item.request.categoria}</Badge>
                      </TableCell>
                      <TableCell>
                        <CriticidadeBadge criticidade={item.response.criticidade} />
                      </TableCell>
                      <TableCell className="text-sm">
                        {formatPercent(item.response.confianca)}
                      </TableCell>
                      <TableCell>
                        {item.response.necessita_escalonamento ? (
                          <Badge variant="destructive">Sim</Badge>
                        ) : (
                          <Badge variant="outline">Não</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatDateTime(item.analisadoEm)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
