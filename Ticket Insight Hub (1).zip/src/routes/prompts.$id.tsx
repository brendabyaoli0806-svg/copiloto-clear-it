import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, History, Save, Trash2, Variable } from "lucide-react";
import { usePromptStore } from "@/hooks/usePromptStore";
import { useHydrated } from "@/hooks/useHydrated";
import { extractVariables, formatRelative, renderTemplate } from "@/utils/format";
import type { PromptScope } from "@/types/ticket";

const scopes: PromptScope[] = ["diagnostico", "resposta", "triagem"];

const sampleVars: Record<string, string> = {
  id: "48219",
  categoria: "Autenticação",
  prioridade: "Alta",
  status: "Aberto",
  descricao: "Usuário não consegue logar após reset de senha.",
  logs: "AUTH_FAIL user=x.silva reason=AD_LOCKED",
};

export const Route = createFileRoute("/prompts/$id")({
  head: () => ({
    meta: [{ title: "Editor de prompt — Copiloto IA" }],
  }),
  component: PromptEditor,
});

function PromptEditor() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const hydrated = useHydrated();
  const template = usePromptStore((s) => s.templates.find((t) => t.id === id));
  const updateTemplate = usePromptStore((s) => s.updateTemplate);
  const deleteTemplate = usePromptStore((s) => s.deleteTemplate);
  const setActive = usePromptStore((s) => s.setActive);

  const [name, setName] = useState(template?.name ?? "");
  const [scope, setScope] = useState<PromptScope>(template?.scope ?? "diagnostico");
  const [body, setBody] = useState(template?.body ?? "");

  const vars = useMemo(() => extractVariables(body), [body]);
  const preview = useMemo(() => renderTemplate(body, sampleVars), [body]);

  if (!hydrated) return <AppLayout title="Editor de prompt">{null}</AppLayout>;

  if (!template) {
    return (
      <AppLayout title="Template não encontrado">
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            <Link to="/prompts" className="text-primary underline">
              Voltar aos templates
            </Link>
          </CardContent>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title={template.name}
      breadcrumb={`Prompt · v${template.version}${template.active ? " · ATIVO" : ""}`}
      actions={
        <div className="flex gap-2">
          <Button asChild size="sm" variant="ghost">
            <Link to="/prompts">
              <ArrowLeft className="mr-1.5 h-4 w-4" />
              Voltar
            </Link>
          </Button>
          <Button
            size="sm"
            onClick={() => {
              updateTemplate(template.id, { name, scope, body });
            }}
          >
            <Save className="mr-1.5 h-4 w-4" />
            Salvar
          </Button>
        </div>
      }
    >
      <div className="mx-auto grid max-w-7xl gap-4 lg:grid-cols-[1fr_360px]">
        <Card className="border-border/60 bg-card/60 backdrop-blur">
          <CardContent className="flex flex-col gap-4 p-5">
            <div className="grid gap-3 sm:grid-cols-[1fr_180px_auto]">
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="!text-base font-display font-semibold"
              />
              <Select value={scope} onValueChange={(v) => setScope(v as PromptScope)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {scopes.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center gap-2 rounded-md border bg-background/40 px-3">
                <span className="text-xs text-muted-foreground">Ativo</span>
                <Switch
                  checked={template.active}
                  onCheckedChange={() => setActive(template.id)}
                />
              </div>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between text-xs">
                <span className="font-semibold uppercase tracking-widest text-muted-foreground">
                  Corpo do prompt
                </span>
                <span className="text-muted-foreground">
                  {body.length} caracteres · v{template.version}
                </span>
              </div>
              <Textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                rows={20}
                className="font-mono text-xs leading-relaxed"
                placeholder="Use {{variavel}} para trechos dinâmicos"
              />
            </div>

            <div>
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                <Variable className="h-3.5 w-3.5" />
                Preview renderizado
              </div>
              <pre className="max-h-64 overflow-auto rounded-lg border bg-background/50 p-3 text-xs leading-relaxed">
                {preview}
              </pre>
            </div>

            <div className="flex justify-end">
              <Button
                size="sm"
                variant="ghost"
                className="text-destructive"
                onClick={() => {
                  if (confirm(`Excluir "${template.name}"?`)) {
                    deleteTemplate(template.id);
                    navigate({ to: "/prompts" });
                  }
                }}
              >
                <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                Excluir template
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col gap-4">
          <Card className="border-border/60 bg-card/60 backdrop-blur">
            <CardContent className="p-4">
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                <Variable className="h-3.5 w-3.5" />
                Variáveis detectadas
              </div>
              {vars.length === 0 ? (
                <p className="text-xs text-muted-foreground">
                  Adicione <code className="rounded bg-muted px-1">{`{{descricao}}`}</code>{" "}
                  no corpo para tornar o prompt dinâmico.
                </p>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {vars.map((v) => (
                    <Badge key={v} variant="outline" className="font-mono">
                      {`{{${v}}}`}
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/60 bg-card/60 backdrop-blur">
            <CardContent className="p-4">
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                <History className="h-3.5 w-3.5" />
                Histórico
              </div>
              <ul className="space-y-2">
                {(template.history ?? []).length === 0 ? (
                  <li className="text-xs text-muted-foreground">
                    Sem versões anteriores.
                  </li>
                ) : (
                  template.history!.map((h) => (
                    <li
                      key={h.version}
                      className="flex items-center justify-between rounded-md border bg-background/40 p-2 text-xs"
                    >
                      <span>
                        v{h.version} · {formatRelative(h.updatedAt)}
                      </span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setBody(h.body)}
                      >
                        Restaurar
                      </Button>
                    </li>
                  ))
                )}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
