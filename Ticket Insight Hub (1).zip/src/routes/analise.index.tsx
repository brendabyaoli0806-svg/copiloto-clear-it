import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppLayout } from "@/layouts/AppLayout";
import { TicketForm } from "@/components/ticket/TicketForm";
import { useAnalisarTicket } from "@/hooks/useAnalisarTicket";
import { LoadingAnalise } from "@/components/ticket/LoadingAnalise";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles } from "lucide-react";
import type { ApiError } from "@/types/ticket";
import { CopilotDrawer } from "@/components/ticket/CopilotDrawer";

export const Route = createFileRoute("/analise/")({
  head: () => ({
    meta: [
      { title: "Nova análise — Copiloto IA" },
      {
        name: "description",
        content:
          "Envie um ticket para o Copiloto IA analisar causa provável, criticidade e próximas ações.",
      },
    ],
  }),
  component: AnalisePage,
});

function AnalisePage() {
  const navigate = useNavigate();
  const mutation = useAnalisarTicket();

  return (
    <AppLayout
      title="Nova análise"
      breadcrumb="Copiloto IA"
      actions={<CopilotDrawer />}
    >
      <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-2">
        <TicketForm
          isPending={mutation.isPending}
          apiError={(mutation.error as ApiError | null) ?? null}
          onSubmit={(payload) => {
            mutation.mutate(payload, {
              onSuccess: () => {
                navigate({
                  to: "/resultado/$id",
                  params: { id: String(payload.id) },
                });
              },
            });
          }}
        />

        <div>
          {mutation.isPending ? (
            <LoadingAnalise />
          ) : (
            <Card className="h-full">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Como funciona
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm text-muted-foreground">
                <p>
                  O Copiloto IA usa RAG + LLM sobre a base de conhecimento e histórico
                  de tickets para produzir um diagnóstico consistente.
                </p>
                <ol className="ml-4 list-decimal space-y-1.5">
                  <li>Preencha os campos do ticket ao lado.</li>
                  <li>Clique em <strong>Analisar com IA</strong>.</li>
                  <li>
                    Receba causa provável, criticidade, confiança, ações recomendadas,
                    indicação de escalonamento e um rascunho de resposta.
                  </li>
                  <li>Consulte os artigos e tickets semelhantes utilizados.</li>
                </ol>
                <p className="text-xs">
                  Nenhuma análise é simulada — todo o resultado vem da API oficial.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
