import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  BookOpen,
  FolderPlus,
  Layers,
  Search,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { useKnowledgeStore } from "@/hooks/useKnowledgeStore";
import { useHydrated } from "@/hooks/useHydrated";
import { formatRelative, truncate } from "@/utils/format";

export const Route = createFileRoute("/conhecimento/")({
  head: () => ({
    meta: [
      { title: "Base de conhecimento — Copiloto IA" },
      {
        name: "description",
        content:
          "Organize categorias e artigos usados pelo Copiloto IA para diagnosticar tickets.",
      },
    ],
  }),
  component: KbPage,
});

function KbPage() {
  const hydrated = useHydrated();
  const categories = useKnowledgeStore((s) => s.categories);
  const articles = useKnowledgeStore((s) => s.articles);
  const createCategory = useKnowledgeStore((s) => s.createCategory);
  const updateCategory = useKnowledgeStore((s) => s.updateCategory);
  const deleteCategory = useKnowledgeStore((s) => s.deleteCategory);
  const [query, setQuery] = useState("");

  const filtered = categories.filter((c) =>
    c.name.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <AppLayout
      title="Base de conhecimento"
      breadcrumb="Inteligência · KB"
      actions={
        <Button
          size="sm"
          onClick={() => createCategory({ name: "Nova categoria" })}
        >
          <FolderPlus className="mr-1.5 h-4 w-4" />
          Nova categoria
        </Button>
      }
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <Card className="border-border/60 bg-card/60 backdrop-blur">
          <CardContent className="flex flex-col gap-4 p-5 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 text-primary">
                <Layers className="h-5 w-5" />
              </div>
              <div>
                <div className="font-display text-lg font-semibold">
                  {categories.length} categorias · {articles.length} artigos
                </div>
                <p className="text-xs text-muted-foreground">
                  Conhecimento local — persistido no navegador, pronto para o Copiloto.
                </p>
              </div>
            </div>
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar categorias..."
                className="pl-9"
              />
            </div>
          </CardContent>
        </Card>

        {!hydrated ? null : filtered.length === 0 ? (
          <EmptyKb onCreate={() => createCategory({ name: "Nova categoria" })} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((cat, i) => {
              const arts = articles.filter((a) => a.categoryId === cat.id);
              return (
                <motion.div
                  key={cat.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Card className="group relative overflow-hidden border-border/60 bg-card/60 transition hover:border-primary/40 hover:shadow-[0_0_30px_oklch(0.78_0.18_210_/_0.18)]">
                    <div
                      className="absolute -right-4 -top-4 h-24 w-24 rounded-full opacity-30 blur-2xl"
                      style={{ background: cat.color }}
                    />
                    <CardContent className="relative flex flex-col gap-4 p-5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <input
                            defaultValue={cat.name}
                            onBlur={(e) =>
                              updateCategory(cat.id, { name: e.target.value })
                            }
                            className="w-full truncate bg-transparent font-display text-lg font-semibold outline-none focus:ring-0"
                          />
                          <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                            <Badge variant="secondary">
                              {arts.length} artigos
                            </Badge>
                            <span>· atualizada {formatRelative(cat.updatedAt)}</span>
                          </div>
                        </div>
                        <input
                          type="color"
                          value={cat.color}
                          onChange={(e) =>
                            updateCategory(cat.id, { color: e.target.value })
                          }
                          className="h-7 w-7 shrink-0 cursor-pointer rounded-md border border-border bg-transparent"
                        />
                      </div>

                      {arts.slice(0, 2).map((a) => (
                        <div
                          key={a.id}
                          className="rounded-lg border border-border/40 bg-background/30 p-2.5 text-xs"
                        >
                          <div className="truncate font-medium text-foreground">
                            {a.title}
                          </div>
                          <div className="mt-0.5 text-muted-foreground">
                            {truncate(a.body.replace(/[#*_>-]/g, ""), 80)}
                          </div>
                        </div>
                      ))}

                      <div className="flex items-center justify-between pt-1">
                        <Button asChild size="sm" variant="ghost">
                          <Link
                            to="/conhecimento/$categoryId"
                            params={{ categoryId: cat.id }}
                          >
                            <BookOpen className="mr-1.5 h-3.5 w-3.5" />
                            Abrir
                          </Link>
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-muted-foreground opacity-0 transition group-hover:opacity-100"
                          onClick={() => {
                            if (confirm(`Excluir "${cat.name}"?`)) deleteCategory(cat.id);
                          }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function EmptyKb({ onCreate }: { onCreate: () => void }) {
  return (
    <Card className="border-dashed">
      <CardContent className="flex flex-col items-center justify-center gap-3 py-14 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
          <BookOpen className="h-6 w-6" />
        </div>
        <div className="text-sm font-medium">Sem categorias por aqui</div>
        <p className="max-w-md text-xs text-muted-foreground">
          Crie categorias como "Rede", "Acesso" ou "Nutanix" e alimente com artigos
          curtos. O Copiloto lateral usa isso automaticamente.
        </p>
        <Button size="sm" onClick={onCreate}>
          <FolderPlus className="mr-1.5 h-4 w-4" />
          Criar primeira categoria
        </Button>
      </CardContent>
    </Card>
  );
}
