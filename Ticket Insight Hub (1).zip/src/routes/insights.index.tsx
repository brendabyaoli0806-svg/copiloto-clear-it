import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useHistoricoStore } from "@/hooks/useHistoricoStore";
import { useKnowledgeStore } from "@/hooks/useKnowledgeStore";
import { usePromptStore } from "@/hooks/usePromptStore";
import { useHydrated } from "@/hooks/useHydrated";
import { KpiCard } from "@/components/ui/KpiCard";
import { RingProgress } from "@/components/ui/RingProgress";
import { NextStepHint } from "@/components/common/NextStepHint";
import {
  Trophy,
  Flame,
  Sparkles,
  BookOpen,
  Wand2,
  ShieldAlert,
  Zap,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/insights/")({
  head: () => ({
    meta: [
      { title: "Insights & gamificação — Copiloto IA" },
      {
        name: "description",
        content: "Nível, conquistas e telemetria da sua operação com o Copiloto IA.",
      },
    ],
  }),
  component: InsightsPage,
});

const badges = [
  { key: "first", label: "Primeira análise", icon: Sparkles, need: 1 },
  { key: "streak5", label: "5 análises", icon: Flame, need: 5 },
  { key: "streak25", label: "25 análises", icon: Trophy, need: 25 },
  { key: "kb3", label: "3 categorias KB", icon: BookOpen, need: 3, kind: "kb" as const },
  { key: "prompt", label: "Template customizado", icon: Wand2, need: 1, kind: "custom-prompt" as const },
];

function InsightsPage() {
  const hydrated = useHydrated();
  const itens = useHistoricoStore((s) => s.itens);
  const categories = useKnowledgeStore((s) => s.categories);
  const templates = usePromptStore((s) => s.templates);

  const total = itens.length;
  const escalonados = itens.filter((i) => i.response.necessita_escalonamento).length;
  const conf =
    total > 0 ? itens.reduce((a, i) => a + i.response.confianca, 0) / total : 0;

  const xp = total * 25 + categories.length * 15 + templates.length * 10;
  const level = Math.floor(xp / 100) + 1;
  const nextLevelXp = level * 100;
  const progress = Math.min(1, xp / nextLevelXp);

  const perCategoria = itens.reduce<Record<string, number>>((acc, i) => {
    const k = i.request.categoria || "Sem categoria";
    acc[k] = (acc[k] ?? 0) + 1;
    return acc;
  }, {});
  const chartData = Object.entries(perCategoria)
    .map(([categoria, qtd]) => ({ categoria, qtd }))
    .sort((a, b) => b.qtd - a.qtd)
    .slice(0, 8);

  const customPrompt = templates.some((t) => !["tpl-diag", "tpl-resp", "tpl-tri"].includes(t.id));

  const unlocked = (b: (typeof badges)[number]) => {
    if (b.kind === "kb") return categories.length >= b.need;
    if (b.kind === "custom-prompt") return customPrompt;
    return total >= b.need;
  };

  return (
    <AppLayout
      title="Insights & Gamificação"
      breadcrumb="Sua evolução como analista IA"
      actions={
        <Button asChild size="sm">
          <Link to="/analise">
            <Sparkles className="mr-1.5 h-4 w-4" />
            Ganhar XP
          </Link>
        </Button>
      }
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        {!hydrated ? null : (
          <>
            <div className="grid gap-4 md:grid-cols-[280px_1fr]">
              <Card className="relative overflow-hidden border-primary/30 bg-gradient-to-br from-primary/15 via-accent/10 to-transparent">
                <CardContent className="flex flex-col items-center gap-3 p-5">
                  <RingProgress value={progress} label={`Nível ${level}`} />
                  <div className="text-center">
                    <div className="font-display text-lg font-semibold">
                      {xp} XP
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Faltam {Math.max(0, nextLevelXp - xp)} XP para o nível {level + 1}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <KpiCard icon={Zap} label="Análises" value={String(total)} tone="primary" />
                <KpiCard
                  icon={ShieldAlert}
                  label="Escalonamentos"
                  value={String(escalonados)}
                  tone="warning"
                  hint={total ? `${Math.round((escalonados / total) * 100)}%` : "—"}
                />
                <KpiCard
                  icon={Trophy}
                  label="Confiança média"
                  value={total ? `${Math.round(conf * 100)}%` : "—"}
                  tone="success"
                />
                <KpiCard
                  icon={BookOpen}
                  label="Categorias KB"
                  value={String(categories.length)}
                  tone="accent"
                />
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              <Card className="border-border/60 bg-card/60 backdrop-blur">
                <CardContent className="p-5">
                  <div className="mb-3 flex items-center justify-between">
                    <div>
                      <div className="font-display text-base font-semibold">
                        Conquistas
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Cada milestone libera um badge — mostre no seu perfil interno.
                      </p>
                    </div>
                    <Badge variant="secondary">
                      {badges.filter(unlocked).length}/{badges.length}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
                    {badges.map((b, i) => {
                      const on = unlocked(b);
                      const Icon = b.icon;
                      return (
                        <motion.div
                          key={b.key}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.05 }}
                          className={[
                            "flex flex-col items-center gap-1.5 rounded-xl border p-3 text-center",
                            on
                              ? "border-primary/40 bg-primary/10 text-foreground shadow-[0_0_25px_oklch(0.78_0.18_210_/_0.2)]"
                              : "border-border/40 bg-background/30 text-muted-foreground opacity-60",
                          ].join(" ")}
                        >
                          <Icon className="h-5 w-5" />
                          <span className="text-[11px] font-medium">{b.label}</span>
                        </motion.div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/60 bg-card/60 backdrop-blur">
                <CardContent className="p-5">
                  <div className="mb-3 font-display text-base font-semibold">
                    Distribuição por categoria
                  </div>
                  {chartData.length === 0 ? (
                    <p className="py-10 text-center text-xs text-muted-foreground">
                      Analise tickets para popular esse gráfico.
                    </p>
                  ) : (
                    <div className="h-64 w-full">
                      <ResponsiveContainer>
                        <BarChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
                          <XAxis dataKey="categoria" tick={{ fontSize: 10 }} stroke="oklch(1 0 0 / 0.4)" />
                          <YAxis allowDecimals={false} tick={{ fontSize: 10 }} stroke="oklch(1 0 0 / 0.4)" />
                          <Tooltip
                            contentStyle={{
                              background: "oklch(0.22 0.03 260)",
                              border: "1px solid oklch(1 0 0 / 0.1)",
                              borderRadius: 8,
                              fontSize: 12,
                            }}
                          />
                          <Bar dataKey="qtd" fill="oklch(0.78 0.18 210)" radius={[6, 6, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <NextStepHint
              title={
                categories.length < 3
                  ? "Amplie sua Base de Conhecimento"
                  : customPrompt
                    ? "Continue evoluindo — próximo nível está pertinho"
                    : "Personalize um template de prompt"
              }
              description={
                categories.length < 3
                  ? "Crie pelo menos 3 categorias para o Copiloto ter contexto rico e ganhar +45 XP."
                  : customPrompt
                    ? "Analise mais tickets ou crie novos artigos para acumular XP."
                    : "Duplique um template e adapte para o seu tom de voz — vale badge."
              }
              actionLabel="Ir agora"
              to={categories.length < 3 ? "/conhecimento" : customPrompt ? "/analise" : "/prompts"}
            />
          </>
        )}
      </div>
    </AppLayout>
  );
}
