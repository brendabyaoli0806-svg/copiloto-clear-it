import { createFileRoute, Link } from "@tanstack/react-router";
import { AppLayout } from "@/layouts/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useHistoricoStore } from "@/hooks/useHistoricoStore";
import { useKnowledgeStore } from "@/hooks/useKnowledgeStore";
import { usePromptStore } from "@/hooks/usePromptStore";
import { useHydrated } from "@/hooks/useHydrated";
import {
  Sparkles,
  ArrowUpRight,
  ShieldAlert,
  TicketIcon,
  Gauge,
  BookOpen,
} from "lucide-react";
import { CriticidadeBadge } from "@/components/ticket/CriticidadeBadge";
import { KpiCard } from "@/components/ui/KpiCard";
import { NextStepHint } from "@/components/common/NextStepHint";
import { formatDateTime, formatPercent, truncate } from "@/utils/format";

export const Route = createFileRoute("/painel/")({
  head: () => ({
    meta: [
      { title: "Painel — Copiloto IA de Tickets" },
      {
        name: "description",
        content:
          "Painel do Copiloto IA de Tickets: acompanhe análises, criticidade e escalonamentos.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const hydrated = useHydrated();
  const itens = useHistoricoStore((s) => s.itens);
  const categorias = useKnowledgeStore((s) => s.categories);
  const templates = usePromptStore((s) => s.templates);

  const total = itens.length;
  const escalonados = itens.filter((i) => i.response.necessita_escalonamento).length;
  const confMedia =
    total > 0 ? itens.reduce((acc, i) => acc + i.response.confianca, 0) / total : 0;
  const recentes = itens.slice(0, 5);

  const hint = !hydrated
    ? null
    : total === 0
      ? {
          title: "Comece analisando seu primeiro ticket",
          description:
            "O Copiloto IA extrai causa provável, ações e um rascunho de resposta em segundos.",
          to: "/analise",
        }
      : categorias.length < 3
        ? {
            title: "Alimente a Base de Conhecimento",
            description:
              "Categorias como Rede, Acesso e Nutanix ajudam o Copiloto a citar artigos precisos.",
            to: "/conhecimento",
          }
        : {
            title: "Suba de nível na aba Insights",
            description:
              "Cada análise, categoria e template rende XP e desbloqueia badges.",
            to: "/insights",
          };

  return (
    <AppLayout
      title="Painel"
      breadcrumb="Visão geral · Clear IT"
      actions={
        <Button asChild size="sm">
          <Link to="/analise">
            <Sparkles className="mr-1.5 h-4 w-4" />
            Nova análise
          </Link>
        </Button>
      }
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <KpiCard icon={TicketIcon} label="Tickets analisados" value={String(total)} hint="persistidos localmente" tone="primary" delay={0} />
          <KpiCard
            icon={ShieldAlert}
            label="Escalonamentos"
            value={String(escalonados)}
            hint={total ? `${Math.round((escalonados / total) * 100)}% do total` : "—"}
            tone="warning"
            delay={0.05}
          />
          <KpiCard
            icon={Gauge}
            label="Confiança média"
            value={total ? formatPercent(confMedia) : "—"}
            tone="success"
            delay={0.1}
          />
          <KpiCard
            icon={BookOpen}
            label="Ativos IA"
            value={`${categorias.length} KB · ${templates.length} prompts`}
            tone="accent"
            delay={0.15}
          />
        </section>

        {hint && (
          <NextStepHint
            title={hint.title}
            description={hint.description}
            actionLabel="Abrir"
            to={hint.to}
          />
        )}

        <Card className="border-border/60 bg-card/60 backdrop-blur">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-base">Análises recentes</CardTitle>
              {total > 0 && (
                <Button asChild variant="ghost" size="sm">
                  <Link to="/tickets">
                    Ver todos
                    <ArrowUpRight className="ml-1 h-3.5 w-3.5" />
                  </Link>
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!hydrated ? null : recentes.length === 0 ? (
              <EmptyState />
            ) : (
              <ul className="divide-y divide-border/60">
                {recentes.map((item) => (
                  <li key={item.request.id} className="py-3 first:pt-0 last:pb-0">
                    <Link
                      to="/resultado/$id"
                      params={{ id: String(item.request.id) }}
                      className="flex flex-col gap-2 rounded-md p-2 transition hover:bg-muted/40 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="font-mono text-xs">
                            #{item.request.id}
                          </Badge>
                          <span className="truncate text-sm font-medium text-foreground">
                            {truncate(item.request.descricao, 80)}
                          </span>
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground">
                          {formatDateTime(item.analisadoEm)} · {item.request.categoria}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <CriticidadeBadge criticidade={item.response.criticidade} />
                        {item.response.necessita_escalonamento && (
                          <Badge variant="destructive">Escalonar</Badge>
                        )}
                        <Badge variant="secondary">
                          {formatPercent(item.response.confianca)}
                        </Badge>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Sparkles className="h-6 w-6" />
      </div>
      <div>
        <div className="text-sm font-medium text-foreground">Nenhuma análise ainda</div>
        <div className="text-xs text-muted-foreground">
          Envie um ticket para o Copiloto IA e veja o diagnóstico completo aqui.
        </div>
      </div>
      <Button asChild size="sm">
        <Link to="/analise">
          <Sparkles className="mr-1.5 h-4 w-4" />
          Analisar primeiro ticket
        </Link>
      </Button>
    </div>
  );
}
