import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { KbArticle, KbCategory } from "@/types/ticket";

const uid = () => Math.random().toString(36).slice(2, 10);
const now = () => new Date().toISOString();

interface KnowledgeState {
  categories: KbCategory[];
  articles: KbArticle[];
  createCategory: (data: Partial<KbCategory>) => KbCategory;
  updateCategory: (id: string, data: Partial<KbCategory>) => void;
  deleteCategory: (id: string) => void;
  createArticle: (categoryId: string, data?: Partial<KbArticle>) => KbArticle;
  updateArticle: (id: string, data: Partial<KbArticle>) => void;
  deleteArticle: (id: string) => void;
  getArticlesByCategory: (categoryId: string) => KbArticle[];
}

const seed: { categories: KbCategory[]; articles: KbArticle[] } = {
  categories: [
    {
      id: "cat-rede",
      name: "Rede & Conectividade",
      color: "#22d3ee",
      icon: "Network",
      createdAt: now(),
      updatedAt: now(),
    },
    {
      id: "cat-acesso",
      name: "Acesso & Autenticação",
      color: "#a78bfa",
      icon: "KeyRound",
      createdAt: now(),
      updatedAt: now(),
    },
    {
      id: "cat-infra",
      name: "Infraestrutura & Servidores",
      color: "#34d399",
      icon: "Server",
      createdAt: now(),
      updatedAt: now(),
    },
  ],
  articles: [
    {
      id: "art-vpn",
      categoryId: "cat-rede",
      title: "Reconexão VPN corporativa",
      body: "## Passos\n\n1. Verifique adaptador de rede\n2. Reinicie o cliente Fortinet\n3. Confirme MFA no app Authenticator\n4. Se persistir, escalar para NOC",
      tags: ["vpn", "fortinet", "mfa"],
      updatedAt: now(),
    },
    {
      id: "art-ad-lock",
      categoryId: "cat-acesso",
      title: "Conta AD bloqueada",
      body: "## Diagnóstico\n\n- Verifique tentativas erradas em Event Viewer\n- Desbloqueie via ADUC\n- Force password reset se >30d\n\n## Comunicação\n\nUse o template `resposta.padrao-desbloqueio`.",
      tags: ["ad", "lock", "senha"],
      updatedAt: now(),
    },
  ],
};

export const useKnowledgeStore = create<KnowledgeState>()(
  persist(
    (set, get) => ({
      categories: seed.categories,
      articles: seed.articles,
      createCategory: (data) => {
        const cat: KbCategory = {
          id: uid(),
          name: data.name ?? "Nova categoria",
          color: data.color ?? "#22d3ee",
          icon: data.icon ?? "Folder",
          createdAt: now(),
          updatedAt: now(),
        };
        set((s) => ({ categories: [cat, ...s.categories] }));
        return cat;
      },
      updateCategory: (id, data) =>
        set((s) => ({
          categories: s.categories.map((c) =>
            c.id === id ? { ...c, ...data, updatedAt: now() } : c,
          ),
        })),
      deleteCategory: (id) =>
        set((s) => ({
          categories: s.categories.filter((c) => c.id !== id),
          articles: s.articles.filter((a) => a.categoryId !== id),
        })),
      createArticle: (categoryId, data) => {
        const art: KbArticle = {
          id: uid(),
          categoryId,
          title: data?.title ?? "Novo artigo",
          body: data?.body ?? "",
          tags: data?.tags ?? [],
          updatedAt: now(),
        };
        set((s) => ({ articles: [art, ...s.articles] }));
        return art;
      },
      updateArticle: (id, data) =>
        set((s) => ({
          articles: s.articles.map((a) =>
            a.id === id ? { ...a, ...data, updatedAt: now() } : a,
          ),
        })),
      deleteArticle: (id) =>
        set((s) => ({ articles: s.articles.filter((a) => a.id !== id) })),
      getArticlesByCategory: (categoryId) =>
        get().articles.filter((a) => a.categoryId === categoryId),
    }),
    {
      name: "clearit-ops:knowledge",
      version: 1,
      storage: createJSONStorage(() =>
        typeof window !== "undefined" ? window.localStorage : (undefined as unknown as Storage),
      ),
    },
  ),
);
