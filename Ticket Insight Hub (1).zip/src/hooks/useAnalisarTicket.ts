import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { analisarTicket } from "@/services/tickets";
import type { ApiError, DiagnosticoResponse, TicketRequest } from "@/types/ticket";
import { useHistoricoStore } from "@/hooks/useHistoricoStore";

export function useAnalisarTicket() {
  const registrar = useHistoricoStore((s) => s.registrar);

  return useMutation<DiagnosticoResponse, ApiError, TicketRequest>({
    mutationFn: analisarTicket,
    onSuccess: (response, request) => {
      registrar({
        request,
        response,
        analisadoEm: new Date().toISOString(),
      });
    },
    onError: (err) => {
      if (err.status !== 422) {
        toast.error(err.message);
      }
    },
  });
}
