import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { PromptScope, PromptTemplate } from "@/types/ticket";
import { defaultSeedTemplates } from "@/utils/promptSeeds";

const uid = () => Math.random().toString(36).slice(2, 10);
const now = () => new Date().toISOString();

interface PromptState {
  templates: PromptTemplate[];
  createTemplate: (data?: Partial<PromptTemplate>) => PromptTemplate;
  updateTemplate: (id: string, data: Partial<PromptTemplate>) => void;
  deleteTemplate: (id: string) => void;
  setActive: (id: string) => void;
  getActive: (scope: PromptScope) => PromptTemplate | undefined;
}

export const usePromptStore = create<PromptState>()(
  persist(
    (set, get) => ({
      templates: defaultSeedTemplates,
      createTemplate: (data) => {
        const tpl: PromptTemplate = {
          id: uid(),
          name: data?.name ?? "Novo template",
          scope: data?.scope ?? "diagnostico",
          body: data?.body ?? "",
          version: 1,
          active: false,
          updatedAt: now(),
          history: [],
        };
        set((s) => ({ templates: [tpl, ...s.templates] }));
        return tpl;
      },
      updateTemplate: (id, data) =>
        set((s) => ({
          templates: s.templates.map((t) => {
            if (t.id !== id) return t;
            const bodyChanged = data.body !== undefined && data.body !== t.body;
            const nextVersion = bodyChanged ? t.version + 1 : t.version;
            const history = bodyChanged
              ? [
                  { version: t.version, body: t.body, updatedAt: t.updatedAt },
                  ...(t.history ?? []),
                ].slice(0, 10)
              : t.history;
            return {
              ...t,
              ...data,
              version: nextVersion,
              history,
              updatedAt: now(),
            };
          }),
        })),
      deleteTemplate: (id) =>
        set((s) => ({ templates: s.templates.filter((t) => t.id !== id) })),
      setActive: (id) =>
        set((s) => {
          const target = s.templates.find((t) => t.id === id);
          if (!target) return s;
          return {
            templates: s.templates.map((t) => ({
              ...t,
              active: t.scope === target.scope ? t.id === id : t.active,
            })),
          };
        }),
      getActive: (scope) =>
        get().templates.find((t) => t.scope === scope && t.active),
    }),
    {
      name: "clearit-ops:prompts",
      version: 2,
      storage: createJSONStorage(() =>
        typeof window !== "undefined" ? window.localStorage : (undefined as unknown as Storage),
      ),
      migrate: (persisted: unknown, _version) => {
        const state = (persisted ?? {}) as Partial<PromptState>;
        const existing = state.templates ?? [];
        const existingNames = new Set(existing.map((t) => t.name));
        const injected = defaultSeedTemplates.filter((t) => !existingNames.has(t.name));
        return { ...state, templates: [...existing, ...injected] } as PromptState;
      },
    },
  ),
);

