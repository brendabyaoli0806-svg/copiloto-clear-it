import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

type Theme = "dark" | "light";

interface SettingsState {
  theme: Theme;
  onboarded: boolean;
  setTheme: (t: Theme) => void;
  toggleTheme: () => void;
  markOnboarded: () => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      theme: "dark",
      onboarded: false,
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set({ theme: get().theme === "dark" ? "light" : "dark" }),
      markOnboarded: () => set({ onboarded: true }),
    }),
    {
      name: "clearit-ops:settings",
      version: 1,
      storage: createJSONStorage(() =>
        typeof window !== "undefined" ? window.localStorage : (undefined as unknown as Storage),
      ),
    },
  ),
);
