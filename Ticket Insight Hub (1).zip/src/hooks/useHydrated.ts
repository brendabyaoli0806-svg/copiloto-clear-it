import { useEffect, useState } from "react";

/** Returns true after client-side hydration, avoiding SSR mismatch. */
export function useHydrated() {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  return hydrated;
}
