import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { AnaliseHistoricoItem } from "@/types/ticket";

interface HistoricoState {
  itens: AnaliseHistoricoItem[];
  registrar: (item: AnaliseHistoricoItem) => void;
  obter: (id: number) => AnaliseHistoricoItem | undefined;
  limpar: () => void;
}

export const useHistoricoStore = create<HistoricoState>()(
  persist(
    (set, get) => ({
      itens: [],
      registrar: (item) =>
        set((state) => {
          const semDuplicata = state.itens.filter(
            (i) => i.request.id !== item.request.id,
          );
          return { itens: [item, ...semDuplicata].slice(0, 100) };
        }),
      obter: (id) => get().itens.find((i) => i.request.id === id),
      limpar: () => set({ itens: [] }),
    }),
    {
      name: "clearit-ops:historico",
      version: 2,
      storage: createJSONStorage(() =>
        typeof window !== "undefined" ? window.localStorage : (undefined as unknown as Storage),
      ),
    },
  ),
);
