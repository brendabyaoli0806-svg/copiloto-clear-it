import type { ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Separator } from "@/components/ui/separator";
import { ThemeToggle } from "@/components/common/ThemeToggle";
import { CommandPaletteTrigger } from "@/components/common/CommandPalette";

interface AppLayoutProps {
  title: string;
  breadcrumb?: string;
  actions?: ReactNode;
  children: ReactNode;
}

export function AppLayout({ title, breadcrumb, actions, children }: AppLayoutProps) {
  return (
    <SidebarProvider>
      <div className="aurora-bg flex min-h-screen w-full">
        <AppSidebar />
        <div className="flex flex-1 flex-col">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border/50 bg-background/70 px-4 backdrop-blur-xl">
            <SidebarTrigger />
            <Separator orientation="vertical" className="h-6" />
            <div className="flex min-w-0 flex-col leading-tight">
              {breadcrumb && (
                <span className="truncate text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  {breadcrumb}
                </span>
              )}
              <h1 className="truncate font-display text-sm font-semibold text-foreground">
                {title}
              </h1>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {actions}
              <CommandPaletteTrigger />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 p-4 md:p-6">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}
