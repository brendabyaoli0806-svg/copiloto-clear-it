export function formatDateTime(iso: string): string {
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export function formatRelative(iso: string): string {
  const d = new Date(iso).getTime();
  if (isNaN(d)) return iso;
  const diff = Date.now() - d;
  const min = Math.floor(diff / 60_000);
  if (min < 1) return "agora";
  if (min < 60) return `há ${min}min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `há ${h}h`;
  const dias = Math.floor(h / 24);
  if (dias < 30) return `há ${dias}d`;
  return formatDateTime(iso);
}

export function toDatetimeLocal(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function fromDatetimeLocal(value: string): string {
  if (!value) return "";
  const d = new Date(value);
  return d.toISOString();
}

export function formatPercent(v: number): string {
  return `${Math.round(v * 100)}%`;
}

export function truncate(text: string, max = 240): string {
  const t = text.trim();
  if (t.length <= max) return t;
  return t.slice(0, max).trimEnd() + "…";
}

export function extractTitulo(texto: string): string {
  const t = texto.trim();
  const tituloMatch = t.match(/T[íi]tulo:\s*\n?([^\n]+)/i);
  if (tituloMatch) return tituloMatch[1].trim();
  const ticketMatch = t.match(/Ticket hist[óo]rico:\s*([^\n]+)/i);
  if (ticketMatch) return `Ticket histórico ${ticketMatch[1].trim()}`;
  return t.split("\n").find((l) => l.trim().length > 0) ?? "Registro";
}

export function renderTemplate(
  body: string,
  vars: Record<string, string | number | undefined>,
): string {
  return body.replace(/\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}/g, (_, key) => {
    const v = vars[key];
    return v === undefined || v === null ? `{{${key}}}` : String(v);
  });
}

export function extractVariables(body: string): string[] {
  const found = new Set<string>();
  const re = /\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}/g;
  let m;
  while ((m = re.exec(body))) found.add(m[1]);
  return Array.from(found);
}
