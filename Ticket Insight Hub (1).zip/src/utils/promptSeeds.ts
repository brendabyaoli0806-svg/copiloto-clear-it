import type { PromptTemplate } from "@/types/ticket";

const now = () => new Date().toISOString();

export const defaultSeedTemplates: PromptTemplate[] = [
  {
    id: "tpl-diag",
    name: "Diagnóstico técnico padrão",
    scope: "diagnostico",
    body: `Você é um analista sênior N2 da Clear IT.

Ticket: {{id}} — {{categoria}} — prioridade {{prioridade}}
Status atual: {{status}}

Descrição:
{{descricao}}

Logs relevantes:
{{logs}}

Diagnostique a causa provável em até 3 linhas e liste 3-5 ações objetivas.`,
    version: 1,
    active: true,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-resp",
    name: "Resposta empática ao cliente",
    scope: "resposta",
    body: `Escreva uma resposta ao cliente sobre o ticket {{id}}.

Contexto: {{descricao}}

Tom: cordial, técnico, direto. Máximo 6 linhas. Inclua próximos passos claros.`,
    version: 1,
    active: true,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-tri",
    name: "Triagem rápida (SLA crítico)",
    scope: "triagem",
    body: `Classifique o ticket {{id}} da categoria {{categoria}}.

Descrição: {{descricao}}

Retorne: nível de criticidade, se requer escalonamento e o time destino.`,
    version: 1,
    active: true,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-rca",
    name: "Análise de causa raiz (RCA)",
    scope: "diagnostico",
    body: `Você é um especialista em análise de incidentes da Clear IT.

Incidente: {{id}}
Serviço afetado: {{servico}}
Impacto: {{impacto}}
Início do problema: {{data_inicio}}

Descrição do incidente:
{{descricao}}

Evidências coletadas:
{{logs}}

Realize uma análise de causa raiz contendo:

1. Causa provável:
2. Evidências que sustentam a hipótese:
3. Possíveis causas alternativas:
4. Ações corretivas recomendadas:
5. Ações preventivas para evitar recorrência.

Se houver baixa evidência, informe o nível de confiança da análise.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-exec",
    name: "Resumo executivo para gestão",
    scope: "resposta",
    body: `Você é um analista de operações de TI responsável por reportar incidentes para gestores.

Ticket: {{id}}

Informações técnicas:
{{descricao}}

Impacto identificado:
{{impacto}}

Gere um resumo executivo contendo:

- O que aconteceu
- Usuários ou serviços afetados
- Impacto no negócio
- Status atual
- Próximas ações
- Previsão de resolução

Use linguagem executiva, sem termos técnicos excessivos.
Máximo 10 linhas.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-rag",
    name: "Sugestão de artigos da base de conhecimento",
    scope: "diagnostico",
    body: `Você é um assistente especialista em base de conhecimento da Clear IT.

Ticket:
{{descricao}}

Pesquise nos artigos disponíveis:

{{artigos_recuperados}}

Retorne:

1. Artigo mais relacionado:
2. Por que este artigo se aplica:
3. Procedimento recomendado:
4. Caso não exista artigo adequado, informe que deve ser criado um novo conhecimento.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-dup",
    name: "Detecção de duplicidade de tickets",
    scope: "triagem",
    body: `Você é um analista responsável pela triagem de chamados.

Novo ticket:
{{novo_ticket}}

Tickets existentes:
{{tickets_existentes}}

Analise se existe duplicidade.

Retorne:

- Existe ticket duplicado? (Sim/Não)
- Ticket relacionado:
- Similaridade estimada (%)
- Justificativa da comparação
- Ação recomendada:
  - Associar
  - Encerrar como duplicado
  - Continuar investigação`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-tasks",
    name: "Geração automática de tarefas técnicas",
    scope: "diagnostico",
    body: `Você é um analista técnico responsável por criar um plano de atendimento.

Ticket:
{{id}}

Problema:
{{descricao}}

Crie um plano técnico contendo:

1. Verificação inicial
2. Comandos ou ferramentas necessárias
3. Validações esperadas
4. Critério de sucesso
5. Plano de rollback caso necessário

Se alguma informação estiver ausente, informe o dado necessário.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-sla",
    name: "Avaliação de SLA",
    scope: "triagem",
    body: `Você é um analista de gestão de SLA.

Ticket:
{{id}}

Prioridade:
{{prioridade}}

Data abertura:
{{data_abertura}}

SLA contratado:
{{sla}}

Status atual:
{{status}}

Avalie:

- Risco de violação do SLA
- Tempo restante estimado
- Fatores que podem atrasar
- Ação recomendada para evitar violação

Classifique o risco:
Baixo / Médio / Alto / Crítico`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-trbl",
    name: "Assistente de troubleshooting guiado",
    scope: "diagnostico",
    body: `Você é um especialista N3 auxiliando um analista N1/N2.

Problema:
{{descricao}}

Ambiente:
{{ambiente}}

Histórico:
{{historico}}

Crie um roteiro de troubleshooting:

Etapa 1:
Objetivo:
Comando/verificação:
Resultado esperado:

Etapa 2:
Objetivo:
Comando/verificação:
Resultado esperado:

Continue até encontrar a possível causa.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-qa",
    name: "Melhoria de qualidade do atendimento",
    scope: "resposta",
    body: `Você é um auditor de qualidade de atendimento ITSM.

Analise o ticket:

Descrição:
{{descricao}}

Solução aplicada:
{{solucao}}

Comentários:
{{comentarios}}

Avalie:

- O ticket possui informações suficientes?
- A solução está documentada corretamente?
- Faltam evidências?
- Pode ser fechado?

Dê uma nota de qualidade de 0 a 10.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-extract",
    name: "Extração automática de campos ITSM",
    scope: "triagem",
    body: `Extraia as informações deste chamado:

Texto:
{{descricao}}

Retorne JSON:

{
 "categoria": "",
 "subcategoria": "",
 "servico": "",
 "impacto": "",
 "urgencia": "",
 "prioridade": "",
 "grupo_responsavel": "",
 "palavras_chave": []
}

Não invente informações ausentes.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
  {
    id: "tpl-close",
    name: "Assistente de fechamento do ticket",
    scope: "resposta",
    body: `Você é responsável pelo encerramento de chamados ITSM.

Ticket:
{{id}}

Problema:
{{descricao}}

Solução aplicada:
{{solucao}}

Crie:

- Resumo da solução
- Evidências coletadas
- Validação realizada
- Orientação ao usuário
- Motivo do encerramento

Use linguagem profissional e objetiva.`,
    version: 1,
    active: false,
    updatedAt: now(),
    history: [],
  },
];
