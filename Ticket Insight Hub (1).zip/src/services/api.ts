import axios, { AxiosError } from "axios";
import type { ApiError } from "@/types/ticket";

export const api = axios.create({
  baseURL: "/api/public",
  timeout: 120_000,
  headers: {
    "Content-Type": "application/json",
  },
});

api.interceptors.response.use(
  (r) => r,
  (error: AxiosError<{ detail?: ApiError["detail"] }>) => {
    const status = error.response?.status ?? 0;
    const detail = error.response?.data?.detail;
    const normalized: ApiError = {
      status,
      message:
        status === 422
          ? "Dados do ticket inválidos. Revise os campos e tente novamente."
          : status >= 500
            ? "A IA não conseguiu processar o ticket agora. Tente novamente."
            : error.message || "Erro de comunicação com a API.",
      detail: Array.isArray(detail) ? detail : undefined,
    };
    return Promise.reject(normalized);
  },
);
