import { api } from "./api";
import type { DiagnosticoResponse, TicketRequest } from "@/types/ticket";

export async function analisarTicket(
  payload: TicketRequest,
): Promise<DiagnosticoResponse> {
  const { data } = await api.post<DiagnosticoResponse>(
    "/analisar-ticket",
    payload,
  );
  return data;
}
