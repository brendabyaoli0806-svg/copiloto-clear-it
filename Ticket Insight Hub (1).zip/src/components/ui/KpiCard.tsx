import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  icon: LucideIcon;
  label: string;
  value: string;
  hint?: string;
  tone?: "primary" | "accent" | "success" | "warning";
  delay?: number;
}

const toneMap = {
  primary: "from-primary/20 to-primary/5 text-primary",
  accent: "from-accent/20 to-accent/5 text-accent",
  success: "from-success/20 to-success/5 text-success",
  warning: "from-warning/20 to-warning/5 text-warning",
};

export function KpiCard({ icon: Icon, label, value, hint, tone = "primary", delay = 0 }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4, ease: "easeOut" }}
    >
      <Card className="relative overflow-hidden border-border/60 bg-card/60 p-5 backdrop-blur-sm transition hover:border-primary/30 hover:shadow-[0_0_30px_oklch(0.78_0.18_210_/_0.15)]">
        <div
          className={cn(
            "absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br opacity-60 blur-2xl",
            toneMap[tone],
          )}
        />
        <div className="relative flex items-center gap-4">
          <div className={cn("flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br", toneMap[tone])}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
              {label}
            </div>
            <div className="mt-0.5 font-display text-2xl font-semibold text-foreground">
              {value}
            </div>
            {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
