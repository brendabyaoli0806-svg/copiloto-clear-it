import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Hash, Layers, ListTree, Signal, FileText } from "lucide-react";
import { formatDateTime } from "@/utils/format";
import type { TicketRequest } from "@/types/ticket";

function Field({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-w-0 items-start gap-3">
      <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="mt-0.5 text-sm text-foreground break-words [overflow-wrap:anywhere]">
          {children}
        </div>
      </div>
    </div>
  );
}


export function TicketDataCard({ ticket }: { ticket: TicketRequest }) {
  return (
    <Card className="h-full min-w-0">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2 min-w-0">
          <CardTitle className="text-base truncate">Dados do ticket</CardTitle>
          <Badge variant="outline" className="shrink-0">#{ticket.id}</Badge>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4 min-w-0">
        <Field icon={Hash} label="ID">
          {ticket.id}
        </Field>
        <Field icon={Signal} label="Status">
          <Badge variant="secondary" className="capitalize">
            {ticket.status}
          </Badge>
        </Field>
        <Field icon={Layers} label="Categoria">
          <span className="capitalize break-words">{ticket.categoria}</span>
        </Field>
        <Field icon={ListTree} label="Prioridade">
          <span className="capitalize">{ticket.prioridade}</span>
        </Field>
        <Field icon={Calendar} label="Criado em">
          {formatDateTime(ticket.criado_em)}
        </Field>
        <Field icon={Clock} label="Prazo final">
          {formatDateTime(ticket.prazo_final)}
        </Field>
        <Field icon={FileText} label="Descrição">
          <p className="whitespace-pre-wrap text-sm leading-relaxed break-words [overflow-wrap:anywhere]">
            {ticket.descricao}
          </p>
        </Field>
        <Field icon={FileText} label="Logs">
          <div className="max-h-56 w-full overflow-auto rounded-md bg-muted p-3">
            <pre className="text-xs leading-relaxed whitespace-pre font-mono">
{ticket.logs}
            </pre>
          </div>
        </Field>
      </CardContent>
    </Card>

  );
}
