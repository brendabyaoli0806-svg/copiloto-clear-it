import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface Props {
  criticidade: string;
  className?: string;
}

export function CriticidadeBadge({ criticidade, className }: Props) {
  const nivel = criticidade?.toLowerCase() ?? "";
  const style =
    nivel.includes("alta") || nivel.includes("crit")
      ? "bg-destructive/15 text-destructive border-destructive/30"
      : nivel.includes("m")
        ? "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30"
        : nivel.includes("baixa")
          ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30"
          : "bg-muted text-muted-foreground border-border";
  return (
    <Badge variant="outline" className={cn("font-medium", style, className)}>
      {criticidade || "—"}
    </Badge>
  );
}
