import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle2, Copy, ShieldAlert, Sparkles } from "lucide-react";
import { CriticidadeBadge } from "./CriticidadeBadge";
import { ConfiancaProgress } from "./ConfiancaProgress";
import type { DiagnosticoResponse } from "@/types/ticket";
import { toast } from "sonner";

export function DiagnosticoCard({ diag }: { diag: DiagnosticoResponse }) {
  const escalonar = diag.necessita_escalonamento;

  const copiar = async () => {
    try {
      await navigator.clipboard.writeText(diag.rascunho_resposta);
      toast.success("Resposta copiada");
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Sparkles className="h-4 w-4 text-primary" />
            Diagnóstico da IA
          </CardTitle>
          <CriticidadeBadge criticidade={diag.criticidade} />
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <ConfiancaProgress valor={diag.confianca} />

        <section>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Causa provável
          </h3>
          <p className="mt-1.5 text-sm leading-relaxed text-foreground">
            {diag.causa_provavel}
          </p>
        </section>

        <section>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Ações recomendadas
          </h3>
          <ol className="mt-2 space-y-2">
            {diag.acoes_recomendadas.map((acao, i) => (
              <li
                key={i}
                className="flex gap-3 rounded-md border bg-card/50 p-3 text-sm"
              >
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                  {i + 1}
                </span>
                <span className="leading-relaxed">{acao}</span>
              </li>
            ))}
          </ol>
        </section>

        <section
          className={
            "flex items-start gap-3 rounded-md border p-3 " +
            (escalonar
              ? "border-destructive/30 bg-destructive/5"
              : "border-emerald-500/30 bg-emerald-500/5")
          }
        >
          {escalonar ? (
            <ShieldAlert className="mt-0.5 h-5 w-5 text-destructive" />
          ) : (
            <CheckCircle2 className="mt-0.5 h-5 w-5 text-emerald-600 dark:text-emerald-400" />
          )}
          <div className="flex-1">
            <div className="text-sm font-semibold">
              {escalonar
                ? "Escalonamento necessário"
                : "Não requer escalonamento"}
            </div>
            <div className="text-xs text-muted-foreground">
              {escalonar
                ? "A IA recomenda encaminhar este ticket para o time responsável."
                : "O time de atendimento pode resolver com o rascunho abaixo."}
            </div>
          </div>
          <Badge variant={escalonar ? "destructive" : "secondary"}>
            {escalonar ? "SIM" : "NÃO"}
          </Badge>
        </section>

        <section>
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Resposta sugerida
            </h3>
            <Button size="sm" variant="ghost" onClick={copiar}>
              <Copy className="mr-1.5 h-3.5 w-3.5" />
              Copiar
            </Button>
          </div>
          <div className="mt-1.5 whitespace-pre-wrap rounded-md border bg-muted/40 p-3 text-sm leading-relaxed">
            {diag.rascunho_resposta}
          </div>
        </section>

        {diag.confianca < 0.5 && (
          <div className="flex items-start gap-2 rounded-md border border-amber-500/30 bg-amber-500/5 p-2.5 text-xs text-amber-800 dark:text-amber-300">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5" />
            Confiança baixa: revise o diagnóstico antes de acionar as ações.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
