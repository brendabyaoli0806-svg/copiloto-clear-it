import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Eye, TicketIcon } from "lucide-react";
import type { TicketSemelhante } from "@/types/ticket";
import { extractTitulo, truncate } from "@/utils/format";

export function TicketsSemelhantesList({
  tickets,
}: {
  tickets: TicketSemelhante[];
}) {
  const [aberto, setAberto] = useState<TicketSemelhante | null>(null);

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <TicketIcon className="h-4 w-4 text-primary" />
              Tickets semelhantes
            </CardTitle>
            <Badge variant="secondary">{tickets.length}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {tickets.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Nenhum ticket semelhante encontrado.
            </p>
          ) : (
            <ul className="grid gap-2 md:grid-cols-2">
              {tickets.map((t, i) => (
                <li
                  key={`${t.id || "sem-id"}-${i}`}
                  className="flex flex-col gap-2 rounded-md border bg-card p-3 hover:border-primary/40 hover:shadow-sm transition"
                >
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">
                      {extractTitulo(t.texto)}
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs">
                      <Badge variant="secondary" className="text-[10px]">
                        {t.categoria || "sem categoria"}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    {truncate(t.texto, 180)}
                  </p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="justify-start"
                    onClick={() => setAberto(t)}
                  >
                    <Eye className="mr-1.5 h-3.5 w-3.5" />
                    Ver detalhes
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!aberto} onOpenChange={(o) => !o && setAberto(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{aberto ? extractTitulo(aberto.texto) : ""}</DialogTitle>
          </DialogHeader>
          {aberto && (
            <pre className="max-h-[60vh] overflow-auto whitespace-pre-wrap rounded-md bg-muted p-3 text-xs leading-relaxed">
              {aberto.texto}
            </pre>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
