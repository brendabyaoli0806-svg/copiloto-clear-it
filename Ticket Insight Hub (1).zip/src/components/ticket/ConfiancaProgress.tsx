import { Progress } from "@/components/ui/progress";
import { formatPercent } from "@/utils/format";

export function ConfiancaProgress({ valor }: { valor: number }) {
  const pct = Math.max(0, Math.min(1, valor)) * 100;
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Confiança da análise</span>
        <span className="font-semibold text-foreground">{formatPercent(valor)}</span>
      </div>
      <Progress value={pct} />
    </div>
  );
}
