import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { BookOpen, Eye } from "lucide-react";
import type { ArtigoUtilizado } from "@/types/ticket";
import { extractTitulo, truncate } from "@/utils/format";

export function ArtigosList({ artigos }: { artigos: ArtigoUtilizado[] }) {
  const [aberto, setAberto] = useState<ArtigoUtilizado | null>(null);

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <BookOpen className="h-4 w-4 text-primary" />
              Artigos utilizados
            </CardTitle>
            <Badge variant="secondary">{artigos.length}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {artigos.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum artigo referenciado.</p>
          ) : (
            <ul className="grid gap-2 md:grid-cols-2">
              {artigos.map((a, i) => (
                <li
                  key={`${a.id}-${i}`}
                  className="flex flex-col gap-2 rounded-md border bg-card p-3 hover:border-primary/40 hover:shadow-sm transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">
                        {extractTitulo(a.texto)}
                      </div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                        <Badge variant="outline" className="font-mono text-[10px]">
                          {a.id}
                        </Badge>
                        <Badge variant="secondary" className="text-[10px]">
                          {a.categoria}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    {truncate(a.texto, 180)}
                  </p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="justify-start"
                    onClick={() => setAberto(a)}
                  >
                    <Eye className="mr-1.5 h-3.5 w-3.5" />
                    Ver conteúdo
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!aberto} onOpenChange={(o) => !o && setAberto(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{aberto ? extractTitulo(aberto.texto) : ""}</DialogTitle>
          </DialogHeader>
          {aberto && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <Badge variant="outline" className="font-mono">
                  {aberto.id}
                </Badge>
                <Badge variant="secondary">{aberto.categoria}</Badge>
              </div>
              <pre className="max-h-[60vh] overflow-auto whitespace-pre-wrap rounded-md bg-muted p-3 text-xs leading-relaxed">
                {aberto.texto}
              </pre>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
