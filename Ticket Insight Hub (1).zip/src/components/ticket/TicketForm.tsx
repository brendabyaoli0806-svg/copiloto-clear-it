import { useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles } from "lucide-react";
import type { ApiError, TicketRequest } from "@/types/ticket";
import { fromDatetimeLocal, toDatetimeLocal } from "@/utils/format";
import { CategoriaCombobox } from "@/components/ticket/CategoriaCombobox";

const schema = z.object({
  id: z.number().int().min(1, "Informe um ID numérico"),
  descricao: z.string().min(3, "Descreva o problema"),
  status: z.string().min(1, "Selecione um status"),
  categoria: z.string().min(1, "Informe a categoria"),
  prioridade: z.string().min(1, "Selecione a prioridade"),
  logs: z.string().min(1, "Cole os logs relacionados"),
  criado_em: z.string().min(1, "Data de criação obrigatória"),
  prazo_final: z.string().min(1, "Prazo final obrigatório"),
});

type FormValues = {
  id: number;
  descricao: string;
  status: string;
  categoria: string;
  prioridade: string;
  logs: string;
  criado_em: string;
  prazo_final: string;
};

interface Props {
  onSubmit: (payload: TicketRequest) => void;
  isPending: boolean;
  apiError?: ApiError | null;
  defaultValues?: Partial<TicketRequest>;
}

const statusOptions = ["Aberto", "Em andamento", "Aguardando cliente", "Resolvido", "Fechado"];
const prioridadeOptions = ["Baixa", "Média", "Alta", "Crítica"];

export function TicketForm({ onSubmit, isPending, apiError, defaultValues }: Props) {
  const now = useMemo(() => new Date(), []);
  const inicial = useMemo<FormValues>(
    () => ({
      id: defaultValues?.id ?? Math.floor(1000 + Math.random() * 9000),
      descricao: defaultValues?.descricao ?? "",
      status: defaultValues?.status ?? "Aberto",
      categoria: defaultValues?.categoria ?? "",
      prioridade: defaultValues?.prioridade ?? "Média",
      logs: defaultValues?.logs ?? "",
      criado_em: defaultValues?.criado_em
        ? toDatetimeLocal(defaultValues.criado_em)
        : toDatetimeLocal(now.toISOString()),
      prazo_final: defaultValues?.prazo_final
        ? toDatetimeLocal(defaultValues.prazo_final)
        : toDatetimeLocal(new Date(now.getTime() + 24 * 3600_000).toISOString()),
    }),
    [defaultValues, now],
  );

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: inicial,
  });

  const submit = handleSubmit((values) => {
    const payload: TicketRequest = {
      ...values,
      id: Number(values.id),
      criado_em: fromDatetimeLocal(values.criado_em),
      prazo_final: fromDatetimeLocal(values.prazo_final),
    };
    onSubmit(payload);
  });

  // Mapeia erros 422 vindos da API para campos do form
  const apiFieldErrors: Record<string, string> = {};
  if (apiError?.status === 422 && apiError.detail) {
    for (const d of apiError.detail) {
      const field = d.loc.filter((x) => x !== "body").join(".");
      if (field) apiFieldErrors[field] = d.msg;
    }
  }

  const status = watch("status");
  const prioridade = watch("prioridade");
  const categoria = watch("categoria");

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Sparkles className="h-4 w-4 text-primary" />
          Novo ticket para análise
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="grid gap-4">
          {apiError && apiError.status === 422 && (
            <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
              {apiError.message}
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="ID" error={errors.id?.message || apiFieldErrors["id"]}>
              <Input type="number" {...register("id", { valueAsNumber: true })} />
            </Field>
            <Field
              label="Categoria"
              error={errors.categoria?.message || apiFieldErrors["categoria"]}
            >
              <CategoriaCombobox
                value={categoria}
                onChange={(v) =>
                  setValue("categoria", v, { shouldValidate: true, shouldDirty: true })
                }
                placeholder="Selecione a categoria..."
              />
            </Field>
            <Field label="Status" error={errors.status?.message || apiFieldErrors["status"]}>
              <Select value={status} onValueChange={(v) => setValue("status", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field
              label="Prioridade"
              error={errors.prioridade?.message || apiFieldErrors["prioridade"]}
            >
              <Select value={prioridade} onValueChange={(v) => setValue("prioridade", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {prioridadeOptions.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field
              label="Criado em"
              error={errors.criado_em?.message || apiFieldErrors["criado_em"]}
            >
              <Input type="datetime-local" {...register("criado_em")} />
            </Field>
            <Field
              label="Prazo final"
              error={errors.prazo_final?.message || apiFieldErrors["prazo_final"]}
            >
              <Input type="datetime-local" {...register("prazo_final")} />
            </Field>
          </div>

          <Field
            label="Descrição"
            error={errors.descricao?.message || apiFieldErrors["descricao"]}
          >
            <Textarea
              rows={4}
              placeholder="Descreva o problema relatado pelo usuário..."
              {...register("descricao")}
            />
          </Field>

          <Field label="Logs" error={errors.logs?.message || apiFieldErrors["logs"]}>
            <Textarea
              rows={6}
              className="font-mono text-xs"
              placeholder="Cole aqui os logs, stack traces ou mensagens de erro relacionadas..."
              {...register("logs")}
            />
          </Field>

          <div className="flex items-center justify-end gap-2 pt-2">
            <Button type="submit" disabled={isPending} className="min-w-56">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  A IA está analisando o ticket...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Analisar com IA
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid gap-1.5 min-w-0">
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
      {error && <span className="text-xs text-destructive">{error}</span>}
    </div>
  );

}
