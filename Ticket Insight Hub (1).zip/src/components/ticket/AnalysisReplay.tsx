import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import {
  Sparkles,
  FileSearch,
  BookOpen,
  Network,
  CheckCheck,
} from "lucide-react";

const passos = [
  { icon: FileSearch, label: "Lendo ticket", desc: "Interpretando descrição e logs" },
  { icon: BookOpen, label: "Consultando base", desc: "Correlacionando com artigos internos" },
  { icon: Network, label: "Comparando histórico", desc: "Buscando tickets semelhantes" },
  { icon: Sparkles, label: "Gerando diagnóstico", desc: "Compondo causa provável e ações" },
  { icon: CheckCheck, label: "Concluído", desc: "Copiloto entregou o resultado" },
];

interface Props {
  running: boolean;
  onFinish?: () => void;
}

export function AnalysisReplay({ running, onFinish }: Props) {
  const [step, setStep] = useState(running ? 0 : passos.length - 1);

  useEffect(() => {
    if (!running) {
      setStep(passos.length - 1);
      return;
    }
    setStep(0);
    const interval = setInterval(() => {
      setStep((s) => {
        if (s >= passos.length - 1) {
          clearInterval(interval);
          onFinish?.();
          return s;
        }
        return s + 1;
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [running, onFinish]);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border/60 bg-gradient-to-br from-card/80 to-card/40 p-5 backdrop-blur-xl">
      <div className="absolute inset-x-0 -top-24 h-48 bg-gradient-to-b from-primary/20 via-accent/10 to-transparent blur-3xl" />
      <div className="relative flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-primary">
        <Sparkles className="h-3.5 w-3.5" />
        Replay da análise IA
      </div>
      <ol className="relative mt-4 grid gap-2 md:grid-cols-5">
        {passos.map((p, i) => {
          const active = i === step;
          const done = i < step;
          const Icon = p.icon;
          return (
            <motion.li
              key={p.label}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className={[
                "relative flex flex-col items-center gap-2 rounded-xl border p-3 text-center transition-all",
                active
                  ? "border-primary/40 bg-primary/10 shadow-[0_0_30px_oklch(0.78_0.18_210_/_0.25)]"
                  : done
                    ? "border-success/30 bg-success/5"
                    : "border-border/40 bg-background/30",
              ].join(" ")}
            >
              <div
                className={[
                  "relative flex h-10 w-10 items-center justify-center rounded-lg",
                  active
                    ? "bg-primary/20 text-primary"
                    : done
                      ? "bg-success/20 text-success"
                      : "bg-muted/60 text-muted-foreground",
                ].join(" ")}
              >
                {active && (
                  <span className="absolute inset-0 animate-ping rounded-lg bg-primary/30" />
                )}
                <Icon className="relative h-4 w-4" />
              </div>
              <div>
                <div className="text-[11px] font-semibold text-foreground">{p.label}</div>
                <div className="text-[10px] leading-tight text-muted-foreground">
                  {p.desc}
                </div>
              </div>
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}
