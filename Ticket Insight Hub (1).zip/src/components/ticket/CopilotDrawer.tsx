import { useMemo, useState } from "react";
import Fuse from "fuse.js";
import { Link } from "@tanstack/react-router";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Copy, Wand2, Bot } from "lucide-react";
import { useKnowledgeStore } from "@/hooks/useKnowledgeStore";
import { usePromptStore } from "@/hooks/usePromptStore";
import { toast } from "sonner";
import { truncate } from "@/utils/format";

export function CopilotDrawer({
  categoria,
  descricao,
}: {
  categoria?: string;
  descricao?: string;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const articles = useKnowledgeStore((s) => s.articles);
  const categories = useKnowledgeStore((s) => s.categories);
  const templates = usePromptStore((s) => s.templates);

  const fuse = useMemo(
    () =>
      new Fuse(articles, {
        keys: ["title", "body", "tags"],
        threshold: 0.4,
      }),
    [articles],
  );

  const q = query.trim() || descricao?.slice(0, 60) || "";
  const suggested = q
    ? fuse.search(q).slice(0, 6).map((r) => r.item)
    : articles.slice(0, 6);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5 border-primary/30 bg-primary/5 text-primary hover:bg-primary/10"
        >
          <Bot className="h-4 w-4" />
          Copiloto
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 font-display">
            <Bot className="h-4 w-4 text-primary" />
            Copiloto lateral
          </SheetTitle>
        </SheetHeader>

        <div className="mt-4 flex flex-col gap-5 px-4 pb-6">
          <Input
            placeholder="Buscar artigos por tema, tag, palavra..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />

          <section>
            <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              <BookOpen className="h-3.5 w-3.5" />
              Artigos sugeridos
            </div>
            {suggested.length === 0 ? (
              <p className="rounded-md border border-dashed p-3 text-xs text-muted-foreground">
                Nenhum artigo cadastrado ainda.{" "}
                <Link to="/conhecimento" className="text-primary underline">
                  Criar KB
                </Link>
              </p>
            ) : (
              <ul className="space-y-2">
                {suggested.map((a) => {
                  const cat = categories.find((c) => c.id === a.categoryId);
                  return (
                    <li
                      key={a.id}
                      className="group rounded-lg border bg-card/60 p-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="truncate text-sm font-medium">{a.title}</div>
                          {cat && (
                            <Badge variant="outline" className="mt-1 text-[10px]">
                              {cat.name}
                            </Badge>
                          )}
                        </div>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7 opacity-60 group-hover:opacity-100"
                          onClick={async () => {
                            await navigator.clipboard.writeText(a.body);
                            toast.success("Conteúdo copiado");
                          }}
                        >
                          <Copy className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                      <p className="mt-1.5 text-xs text-muted-foreground">
                        {truncate(a.body.replace(/[#*_>-]/g, ""), 140)}
                      </p>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          <section>
            <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              <Wand2 className="h-3.5 w-3.5" />
              Templates ativos
            </div>
            <ul className="space-y-2">
              {templates
                .filter((t) => t.active)
                .map((t) => (
                  <li
                    key={t.id}
                    className="flex items-center justify-between rounded-lg border bg-card/60 p-2.5"
                  >
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">{t.name}</div>
                      <Badge variant="secondary" className="mt-1 text-[10px] uppercase">
                        {t.scope}
                      </Badge>
                    </div>
                    <Button asChild size="sm" variant="ghost">
                      <Link
                        to="/prompts/$id"
                        params={{ id: t.id }}
                        onClick={() => setOpen(false)}
                      >
                        Abrir
                      </Link>
                    </Button>
                  </li>
                ))}
            </ul>
          </section>

          <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-xs text-muted-foreground">
            💡 <strong className="text-foreground">Dica:</strong> {categoria
              ? `use artigos da categoria relacionada a "${categoria}" para enriquecer sua descrição.`
              : "preencha a categoria para receber sugestões contextuais."}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
