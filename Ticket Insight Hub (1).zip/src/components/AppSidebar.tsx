import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Ticket,
  Sparkles,
  BookOpen,
  Wand2,
  TrendingUp,
  Zap,
  Home,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

const grupos = [
  {
    label: "Operação",
    items: [
      { title: "Manifesto", url: "/", icon: Home },
      { title: "Painel", url: "/painel", icon: LayoutDashboard },
      { title: "Nova análise", url: "/analise", icon: Sparkles },
      { title: "Tickets", url: "/tickets", icon: Ticket },
    ],
  },
  {
    label: "Inteligência",
    items: [
      { title: "Base de conhecimento", url: "/conhecimento", icon: BookOpen },
      { title: "Templates de prompt", url: "/prompts", icon: Wand2 },
      { title: "Insights", url: "/insights", icon: TrendingUp },
    ],
  },
];

export function AppSidebar() {
  const pathname = useRouterState({ select: (r) => r.location.pathname });

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <div className="flex items-center gap-2.5 px-2 py-3">
          <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-[0_0_20px_oklch(0.78_0.18_210_/_0.4)]">
            <Zap className="h-4 w-4" strokeWidth={2.5} />
          </div>
          <div className="flex flex-col leading-tight group-data-[collapsible=icon]:hidden">
            <span className="font-display text-sm font-semibold tracking-tight">
              Clear IT · Ops OS
            </span>
            <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
              Copiloto IA
            </span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        {grupos.map((grupo) => (
          <SidebarGroup key={grupo.label}>
            <SidebarGroupLabel>{grupo.label}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {grupo.items.map((item) => {
                  const active =
                    item.url === "/"
                      ? pathname === "/"
                      : pathname === item.url || pathname.startsWith(item.url + "/");
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild isActive={active} tooltip={item.title}>
                        <Link to={item.url} className="flex items-center gap-2.5">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
    </Sidebar>
  );
}
