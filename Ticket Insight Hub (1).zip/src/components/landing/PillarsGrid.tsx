import { motion } from "framer-motion";
import { Clock, BookOpen, MessageSquareQuote } from "lucide-react";

const pillars = [
  {
    icon: Clock,
    title: "Diagnóstico em 10s",
    text: "Da abertura do ticket ao insight acionável — no exato segundo da crise.",
    tone: "from-primary/30 to-primary/5 text-primary",
  },
  {
    icon: BookOpen,
    title: "Conhecimento tribal vira ativo",
    text: "Cada resolução alimenta a base e transforma tácito em ativo replicável.",
    tone: "from-accent/30 to-accent/5 text-accent",
  },
  {
    icon: MessageSquareQuote,
    title: "Rascunho pronto pro cliente",
    text: "Resposta cordial e técnica, formatada e revisável antes de enviar.",
    tone: "from-success/30 to-success/5 text-success",
  },
];

export function PillarsGrid() {
  return (
    <section className="mx-auto grid w-full max-w-6xl gap-4 px-6 pb-8 md:grid-cols-3 md:pb-16">
      {pillars.map((p, i) => (
        <motion.div
          key={p.title}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.08, duration: 0.5 }}
          className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card/40 p-5 backdrop-blur-xl"
        >
          <div
            className={`absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br opacity-40 blur-2xl ${p.tone}`}
          />
          <div className="relative">
            <div
              className={`mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${p.tone}`}
            >
              <p.icon className="h-5 w-5" />
            </div>
            <h3 className="font-display text-lg font-semibold">{p.title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{p.text}</p>
          </div>
        </motion.div>
      ))}
    </section>
  );
}
