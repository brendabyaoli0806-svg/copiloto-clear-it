import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { Sparkles, ArrowRight, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export function HeroManifesto() {
  return (
    <section className="relative overflow-hidden">
      {/* Aurora background */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute right-0 top-40 h-[400px] w-[500px] rounded-full bg-accent/20 blur-[120px]" />
        <div className="absolute bottom-0 left-0 h-[400px] w-[500px] rounded-full bg-success/10 blur-[120px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,_oklch(0.78_0.18_210_/_0.08)_1px,_transparent_0)] [background-size:32px_32px]" />
      </div>

      <div className="mx-auto flex max-w-6xl flex-col items-center px-6 py-20 text-center md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/40 px-3.5 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur"
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          Copiloto IA da Clear IT · Junho 2026
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08, duration: 0.6 }}
          className="max-w-4xl font-display text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl"
        >
          Dar ao{" "}
          <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            L1
          </span>{" "}
          a experiência de um{" "}
          <span className="bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent">
            L3
          </span>
          , no exato segundo da crise.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.18, duration: 0.6 }}
          className="mt-6 max-w-2xl text-base text-muted-foreground md:text-lg"
        >
          O Copiloto de Suporte L1 transforma o conhecimento tribal da Clear IT em{" "}
          <span className="text-foreground">diagnóstico</span>,{" "}
          <span className="text-foreground">ações recomendadas</span> e{" "}
          <span className="text-foreground">rascunho de resposta</span> — entregues em
          até <span className="text-primary">10 segundos</span>, direto no ticket.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.28, duration: 0.5 }}
          className="mt-10 flex flex-col gap-3 sm:flex-row"
        >
          <Button
            asChild
            size="lg"
            className="relative overflow-hidden bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-[0_0_40px_-8px_oklch(0.78_0.18_210_/_0.6)] hover:shadow-[0_0_60px_-8px_oklch(0.78_0.18_210_/_0.8)]"
          >
            <Link to="/painel">
              <Zap className="mr-2 h-4 w-4" />
              Entrar no Copiloto
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="border-border/60 bg-card/40 backdrop-blur">
            <Link to="/analise">
              <Sparkles className="mr-2 h-4 w-4" />
              Analisar um ticket agora
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
