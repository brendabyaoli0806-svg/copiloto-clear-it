import { motion } from "framer-motion";
import { Mail } from "lucide-react";

interface Props {
  initials: string;
  name: string;
  area: string;
  highlight?: boolean;
  delay?: number;
  gradient: string;
}

export function MemberCard({ initials, name, area, highlight, delay = 0, gradient }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.5, ease: "easeOut" }}
      whileHover={{ y: -4 }}
      className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card/40 p-5 backdrop-blur-xl transition-shadow hover:shadow-[0_10px_40px_-15px_oklch(0.78_0.18_210_/_0.5)]"
    >
      <div
        className={`absolute -right-8 -top-8 h-32 w-32 rounded-full opacity-30 blur-3xl transition-opacity group-hover:opacity-60 ${gradient}`}
      />
      <div className="relative flex flex-col items-start gap-3">
        <div
          className={`flex h-14 w-14 items-center justify-center rounded-2xl font-display text-lg font-bold text-white shadow-lg ${gradient}`}
        >
          {initials}
        </div>
        <div>
          <div className="font-display text-sm font-semibold leading-tight">{name}</div>
          <div className="mt-1 text-xs text-muted-foreground">{area}</div>
        </div>
        {highlight && (
          <div className="mt-1 inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-primary">
            <Mail className="h-3 w-3" />
            Contato
          </div>
        )}
      </div>
    </motion.div>
  );
}
