import { motion } from "framer-motion";
import { MemberCard } from "./MemberCard";

const members = [
  {
    initials: "BB",
    name: "Brenda Beatryz da Silva Oliveira",
    area: "Tecnologia e Produto",
    highlight: true,
    gradient: "bg-gradient-to-br from-primary to-accent",
  },
  {
    initials: "EA",
    name: "Eduardo Augusto Carvalho Silva Brito",
    area: "Tecnologia e Produto",
    gradient: "bg-gradient-to-br from-accent to-primary",
  },
  {
    initials: "KJ",
    name: "Kayk Junior Da Silva Trindade",
    area: "Tecnologia e Produto",
    gradient: "bg-gradient-to-br from-primary via-accent to-primary",
  },
  {
    initials: "RP",
    name: "Raul Pereira França",
    area: "Negócios e Estratégia",
    gradient: "bg-gradient-to-br from-warning to-accent",
  },
  {
    initials: "VV",
    name: "Vinícius Vieira de Souza",
    area: "Negócios e Estratégia",
    gradient: "bg-gradient-to-br from-success to-primary",
  },
];

export function SquadSection() {
  return (
    <section className="mx-auto w-full max-w-6xl px-6 py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="mb-10 flex flex-col items-center text-center"
      >
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/40 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground backdrop-blur">
          Squad B.4 · PPM 2026
        </div>
        <h2 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
          Squad{" "}
          <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            Tech Tigers
          </span>
        </h2>
        <p className="mt-3 max-w-2xl text-sm text-muted-foreground md:text-base">
          O time por trás do Copiloto. Squad B.4 do PPM 2026, cobrindo produto,
          tecnologia, negócios e estratégia.
        </p>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        {members.map((m, i) => (
          <MemberCard key={m.initials} {...m} delay={i * 0.06} />
        ))}
      </div>
    </section>
  );
}
