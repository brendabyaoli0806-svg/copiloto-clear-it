import { motion } from "framer-motion";
import { Lightbulb, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

interface Props {
  title: string;
  description: string;
  actionLabel?: string;
  to?: string;
  onAction?: () => void;
  icon?: ReactNode;
}

export function NextStepHint({
  title,
  description,
  actionLabel,
  to,
  onAction,
  icon,
}: Props) {
  const inner = (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative flex items-start gap-3 overflow-hidden rounded-xl border border-primary/20 bg-gradient-to-br from-primary/10 via-accent/5 to-transparent p-4"
    >
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
        {icon ?? <Lightbulb className="h-4 w-4" />}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-semibold uppercase tracking-widest text-primary">
            Próximo passo
          </span>
        </div>
        <div className="mt-0.5 font-display text-sm font-semibold text-foreground">
          {title}
        </div>
        <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
          {description}
        </p>
      </div>
      {actionLabel && (
        <div className="ml-2 flex shrink-0 items-center gap-1 self-center text-xs font-medium text-primary opacity-70 transition group-hover:opacity-100">
          {actionLabel}
          <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
        </div>
      )}
    </motion.div>
  );

  if (to) {
    return (
      <Link to={to} className="block">
        {inner}
      </Link>
    );
  }
  if (onAction) {
    return (
      <button type="button" onClick={onAction} className="block w-full text-left">
        {inner}
      </button>
    );
  }
  return inner;
}
