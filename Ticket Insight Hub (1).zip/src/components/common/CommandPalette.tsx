import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { Button } from "@/components/ui/button";
import {
  BookOpen,
  Home,
  LayoutDashboard,
  Moon,
  Search,
  Sparkles,
  Ticket,
  TrendingUp,
  Wand2,
} from "lucide-react";
import { useSettingsStore } from "@/hooks/useSettingsStore";
import { useHistoricoStore } from "@/hooks/useHistoricoStore";
import { useKnowledgeStore } from "@/hooks/useKnowledgeStore";
import { truncate } from "@/utils/format";

export function CommandPaletteTrigger() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="hidden gap-2 border-border/60 bg-background/40 pl-2.5 pr-1.5 text-xs text-muted-foreground shadow-sm hover:text-foreground md:inline-flex"
        onClick={() => setOpen(true)}
      >
        <Search className="h-3.5 w-3.5" />
        Buscar
        <kbd className="ml-1 rounded border border-border/80 bg-muted/50 px-1.5 py-0.5 font-mono text-[10px]">
          ⌘K
        </kbd>
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden"
        onClick={() => setOpen(true)}
        aria-label="Abrir command palette"
      >
        <Search className="h-4 w-4" />
      </Button>
      <CommandPalette open={open} onOpenChange={setOpen} />
    </>
  );
}

function CommandPalette({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const navigate = useNavigate();
  const toggleTheme = useSettingsStore((s) => s.toggleTheme);
  const historico = useHistoricoStore((s) => s.itens);
  const articles = useKnowledgeStore((s) => s.articles);
  const categories = useKnowledgeStore((s) => s.categories);

  const go = (fn: () => void) => {
    onOpenChange(false);
    setTimeout(fn, 50);
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Buscar rotas, tickets, artigos, templates..." />
      <CommandList>
        <CommandEmpty>Nada encontrado.</CommandEmpty>
        <CommandGroup heading="Navegar">
          <CommandItem onSelect={() => go(() => navigate({ to: "/" }))}>
            <Home className="h-4 w-4" />
            Manifesto
          </CommandItem>
          <CommandItem onSelect={() => go(() => navigate({ to: "/painel" }))}>
            <LayoutDashboard className="h-4 w-4" />
            Painel
          </CommandItem>
          <CommandItem onSelect={() => go(() => navigate({ to: "/analise" }))}>
            <Sparkles className="h-4 w-4" />
            Nova análise
          </CommandItem>
          <CommandItem onSelect={() => go(() => navigate({ to: "/tickets" }))}>
            <Ticket className="h-4 w-4" />
            Tickets analisados
          </CommandItem>
          <CommandItem onSelect={() => go(() => navigate({ to: "/conhecimento" }))}>
            <BookOpen className="h-4 w-4" />
            Base de conhecimento
          </CommandItem>
          <CommandItem onSelect={() => go(() => navigate({ to: "/prompts" }))}>
            <Wand2 className="h-4 w-4" />
            Templates de prompt
          </CommandItem>
          <CommandItem onSelect={() => go(() => navigate({ to: "/insights" }))}>
            <TrendingUp className="h-4 w-4" />
            Insights & gamificação
          </CommandItem>
        </CommandGroup>

        {historico.length > 0 && (
          <>
            <CommandSeparator />
            <CommandGroup heading="Tickets recentes">
              {historico.slice(0, 5).map((h) => (
                <CommandItem
                  key={h.request.id}
                  onSelect={() =>
                    go(() =>
                      navigate({
                        to: "/resultado/$id",
                        params: { id: String(h.request.id) },
                      }),
                    )
                  }
                >
                  <Ticket className="h-4 w-4" />#{h.request.id} — {truncate(h.request.descricao, 50)}
                </CommandItem>
              ))}
            </CommandGroup>
          </>
        )}

        {categories.length > 0 && (
          <>
            <CommandSeparator />
            <CommandGroup heading="Categorias KB">
              {categories.map((c) => (
                <CommandItem
                  key={c.id}
                  onSelect={() =>
                    go(() =>
                      navigate({
                        to: "/conhecimento/$categoryId",
                        params: { categoryId: c.id },
                      }),
                    )
                  }
                >
                  <BookOpen className="h-4 w-4" />
                  {c.name}
                </CommandItem>
              ))}
            </CommandGroup>
          </>
        )}

        {articles.length > 0 && (
          <>
            <CommandSeparator />
            <CommandGroup heading="Artigos">
              {articles.slice(0, 8).map((a) => (
                <CommandItem
                  key={a.id}
                  onSelect={() =>
                    go(() =>
                      navigate({
                        to: "/conhecimento/$categoryId",
                        params: { categoryId: a.categoryId },
                        search: { article: a.id },
                      }),
                    )
                  }
                >
                  <BookOpen className="h-4 w-4" />
                  {a.title}
                </CommandItem>
              ))}
            </CommandGroup>
          </>
        )}

        <CommandSeparator />
        <CommandGroup heading="Ações">
          <CommandItem onSelect={() => go(() => toggleTheme())}>
            <Moon className="h-4 w-4" />
            Alternar tema claro/escuro
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
